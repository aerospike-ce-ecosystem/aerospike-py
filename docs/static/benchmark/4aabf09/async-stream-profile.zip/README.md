# Async iterator profile at PR #500

The `observed/` directory contains the release-wheel measurements, independent counts of Future suspensions and drainer callbacks, the runtime/transport matrix, and the results from separately instrumented PR wheels. End-to-end scans used 12,000 rows, two bins (an integer and a 160-byte string), an expected checksum of 73,914,000, and one sequential async consumer. All controls used uvloop 0.23.0.

The four cProfile tables retain function names, source basenames or package-relative paths, counts and timings. `native-stack-counts.json` retains selected counts from native sampling. The archive omits host-specific OS stack dumps, binary .pstats files and sampler messages containing local file locations. The commands below can regenerate these locally. Aggregate process and event-loop CPU metrics are independent of the samplers. Wall-clock samples include waiting threads.
## Prepare the measured build

Prerequisites are Git, uv with managed CPython downloads, a Rust toolchain supporting the measured checkout, and Docker or Podman for a local database. The async workloads use uvloop on macOS or Linux. The published host was an Apple M4 Pro with 12 cores and 24 GiB of RAM, running a single CE 8.2.0.1 node in a Podman VM with 5 vCPUs and 11,444 MiB. The results include CPU contention between the client and that VM.

Extract this ZIP into its own directory and start a shell there. Run the following blocks in the same shell. They create a fresh run directory under the extraction directory and keep new output separate from the shipped `observed/` files. The benchmark code was measured at the exact commit below. If you already have the repository, set `REPO` to its absolute path before starting. Your docs checkout can remain on a different revision.

```sh
set -eu
BUNDLE=$(pwd -P)
RUN=$(mktemp -d "$BUNDLE/run.XXXXXX")
COMMIT=4aabf09f7ca1911a5ba00a3d668ec799c19ed54c
if [ -z "${REPO:-}" ]; then
    REPO="$RUN/repository"
    git clone --no-checkout https://github.com/aerospike-ce-ecosystem/aerospike-py.git "$REPO"
fi
if ! git -C "$REPO" cat-file -e "$COMMIT^{commit}"; then
    git -C "$REPO" fetch origin refs/pull/500/head
fi
git -C "$REPO" worktree add --detach "$RUN/src" "$COMMIT"
test "$(git -C "$RUN/src" rev-parse HEAD)" = "$COMMIT"
uv python install 3.14.2 3.14.2t

build_pair() {
    SOURCE=$1
    ENVS=$2
    for mode in gil ft; do
        py=3.14.2
        if [ "$mode" = ft ]; then py=3.14.2t; fi
        uv venv "$ENVS/$mode" --python "$py"
        interp="$ENVS/$mode/bin/python"
        uv pip install --python "$interp" numpy==2.5.5 uvloop==0.23.0 aerospike-sdk==1.0.0 aerospike-native==1.0.0
        (cd "$SOURCE" && uvx --from 'maturin>=1.9,<2' maturin build --release --locked -i "$interp" -o "$ENVS/wheels/$mode")
        uv pip install --no-deps --python "$interp" "$ENVS/wheels/$mode"/*.whl
    done
}
mkdir -p "$RUN/results" "$RUN/release"
build_pair "$RUN/src" "$RUN/release"
GIL="$RUN/release/gil/bin/python"
FT="$RUN/release/ft/bin/python"
unset PYTHON_GIL AEROSPIKE_PIPE_WAKE
```

## Start one local server

Use a writable `test` namespace in a dedicated single-node Community Edition server. The commands below advertise a loopback address to the host interpreters and set the cluster name expected by the harness. Select an available port with `AEROSPIKE_PORT` (default 18710); `CONTAINER_ENGINE=podman` selects Podman. If you already have a matching server, export its host, port, namespace and cluster name and skip container creation. Each driver seeds a unique set and removes its own keys after the run.

```sh
ENGINE=${CONTAINER_ENGINE:-docker}
export AEROSPIKE_HOST=127.0.0.1
export AEROSPIKE_PORT=${AEROSPIKE_PORT:-18710}
export AEROSPIKE_NAMESPACE=test AEROSPIKE_CLUSTER=docker AEROSPIKE_CLUSTER_NAME=docker
DB_ID=$("$ENGINE" run -d --rm -p "127.0.0.1:$AEROSPIKE_PORT:3000" \
    -e NAMESPACE=test -e CLUSTER_NAME=docker -e DEFAULT_TTL=2592000 \
    -e ACCESS_PORT="$AEROSPIKE_PORT" \
    -v "$RUN/src/scripts/aerospike.template.conf:/etc/aerospike/aerospike.template.conf:ro" \
    docker.io/library/aerospike:ce-8.2.0.1_1)
until "$ENGINE" exec "$DB_ID" asinfo -v status 2>/dev/null | grep -qw ok; do
    test "$("$ENGINE" inspect -f '{{.State.Running}}' "$DB_ID")" = true
    sleep 1
done
```

Run only one measurement driver at a time on the otherwise idle host. Measurements use three warm trials unless the workload below specifies another design. Use `"$ENGINE" stop "$DB_ID"` after completing the experiments if you created the server above.

## Release-wheel profiles and controls

Run the following once in the fresh results directory. The original iterator test times one warmed complete scan in each of three fresh processes per condition. The refill experiment times five runs per cap and counts Future suspensions separately from timing. The wake-transport controls repeat in five rotated rounds and run the dedicated drain counter after the timing loop. Consumer-stage times are arithmetic means of seven runs.

```sh
S="$BUNDLE/scripts"
R="$RUN/results"
"$GIL" "$S/original_scan.py" --run "$GIL" "$FT" > "$R/original-stream.jsonl"
"$GIL" "$S/profile_stream.py" --run "$GIL" "$FT" --out "$R"
"$GIL" "$S/pr_batch_probe.py" --run "$GIL" "$FT" > "$R/pr-batch-samples.jsonl"
"$GIL" "$S/runtime_controls.py" run "$GIL" "$FT" --output "$R/controls.jsonl"
"$GIL" "$S/consumer_stages.py" run "$FT" "$R/consumer-stages.jsonl"
"$GIL" "$S/summarize_controls.py" "$R"
"$GIL" "$S/summarize_profile.py" "$R"
```

On macOS, `profile_stream.py` uses libproc thread counters and the system `sample` command while repeatedly consuming scans. It saves local native .txt.gz stacks and Python .pstats alongside cProfile JSON. On other Unix hosts this runner collects the applicable Python and timing results and omits the macOS sampler and thread groups. Do not copy the shipped macOS native counts into a new run. For the release-wheel baseline, three independent trials each produced five unprofiled full scans per condition. The A/B experiments use separate processes for stock CPython, the FT binary with GIL off, and the same FT binary with GIL enabled. The SDK bridge counter runs on the same fixture as the wake controls. Its `native_anext_called` and `native_future_pending_on_return` fields include the call reporting EOF.

## Instrument Rust record conversion

Create a second detached worktree and a separate pair of interpreters for the diagnostic extension. The instrumenter changes the disposable source copy. The release interpreters from the earlier step continue to load the original build. The table uses seven repeats per interpreter and condition. Zero stage counters on coarse-timing runs indicate disabled detailed instrumentation.

```sh
git -C "$REPO" worktree add --detach "$RUN/diag-src" "$COMMIT"
"$GIL" "$S/instrument_native.py" "$RUN/diag-src"
mkdir -p "$RUN/diag"
build_pair "$RUN/diag-src" "$RUN/diag"
"$GIL" "$S/pr_native_timing.py" --run "$RUN/release" "$RUN/diag" > "$R/pr-native-samples.jsonl"
"$GIL" "$S/summarize_pr_native.py" "$R"
```

Each experiment uses a new private set in the specified test namespace. Preserve the `results/` directory if you want to compare runs. All timing numbers depend on the interpreter, SDK, server, event loop and host resources.
