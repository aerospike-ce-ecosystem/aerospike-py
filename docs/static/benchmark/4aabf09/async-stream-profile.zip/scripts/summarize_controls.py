"""Summarize scan, refill, wake and consumer measurements in an output directory."""
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path
from statistics import median, mean

root = Path(sys.argv[1])
def group(filename, keys):
    groups = defaultdict(list)
    for line in (root / filename).read_text().splitlines():
        row = json.loads(line)
        groups[tuple(row[k] for k in keys)].append(row)
    return groups

def write(name, header, rows):
    with (root / name).open('w', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(header.split())
        writer.writerows(rows)

def middle(rows, key, places=3):
    return round(median(r[key] for r in rows), places)

table = []
for (gil, mode), rows in group('pr-batch-samples.jsonl', ('gil', 'mode')).items():
    assert len(rows) == 5
    walls = [r['wall_ms'] for r in rows]
    table.append((gil, mode, len(rows), middle(rows, 'wall_ms'), middle(rows,'process_cpu_ms'),
                  f'{min(walls):.2f}..{max(walls):.2f}', *[middle(rows,k) for k in
                  ('nonempty_refills','eof_refills','native_future_yields')]))
write('pr-batch-summary.csv','gil mode trials wall_ms cpu_ms wall_range nonempty_refills eof_refills native_future_yields',table)

table = []
for keys, rows in sorted(group('controls.jsonl', ('client','mode','wake','access')).items()):
    assert len(rows) == 5
    walls = [r['wall_ms'] for r in rows]
    table.append((*keys,len(rows),*[middle(rows,k) for k in ('wall_ms','cpu_ms','loop_cpu_ms')],
                  round(min(walls),3),round(max(walls),3)))
write('runtime-summary.csv','client mode transport_env row_access trials median_wall_ms median_proc_cpu_ms median_event_loop_cpu_ms min_wall_ms max_wall_ms',table)

fields = ['wall_ms','refill_wall_ms','other_wall_ms','inside_refill_loop_cpu_ms','other_loop_cpu_ms']
table = []
for (mode,), rows in group('consumer-stages.jsonl', ('mode',)).items():
    assert len(rows) == 7
    table.append((mode,len(rows),*[round(mean(r[k] for r in rows),3) for k in fields]))
write('consumer-stages-summary.csv','mode runs '+' '.join('mean_'+k for k in fields), table)

table = []
for (gil, client), rows in group('original-stream.jsonl', ('gil','client')).items():
    assert len(rows) == 3 and all(r['records']==12000 and r['checksum']==73914000 for r in rows)
    table.append((gil,client,len(rows),middle(rows,'wall_ms'),middle(rows,'cpu_ms')))
write('original-stream-summary.csv','gil client trials wall_ms cpu_ms',table)
