"""Receive identical default-cap PR query streams; measure conversion inside diagnostic wheels.

Usage: /release/gil/bin/python pr_native_timing.py --run /production/root /diagnostic/root > pr-native-samples.jsonl
Each root contains gil/bin/python and ft/bin/python. Diagnostic wheels use instrument_native.py.
"""
import argparse
import asyncio
import hashlib
import json
import logging
import os
from pathlib import Path
import subprocess
import sys
import sysconfig
import time
import uuid

N = 12000
PAD = "ap" * 80
NS = os.getenv("AEROSPIKE_NAMESPACE", "test")
CONFIG = {"hosts": [(os.getenv("AEROSPIKE_HOST", "127.0.0.1"), int(os.getenv("AEROSPIKE_PORT", "18710")))],
          "cluster_name": os.getenv("AEROSPIKE_CLUSTER_NAME", "docker")}
FIELDS = ("refills","rows","conversion_ns","trace_ns","key_ns","meta_ns","bins_ns","tuple_ns")


async def scan(client, ds):
    seen = bytearray(N)
    checksum = count = 0
    start, cpu = time.perf_counter_ns(), time.process_time_ns()
    async with client.query(NS, ds).stream() as stream:
        async for row in stream:
            bins = row.bins
            k, val = bins["v"], bins["pad"]
            if not (0 <= k < N) or seen[k] or val != PAD:
                raise ValueError("invalid record")
            seen[k] = 1
            checksum += k + len(val)
            count += 1
    wall, cpu = (time.perf_counter_ns()-start)/1e6, (time.process_time_ns()-cpu)/1e6
    assert count == N and checksum == 73_914_000
    return {"wall_ms":wall,"process_cpu_ms":cpu,"checksum":checksum}


async def child(args):
    import aerospike_py as ap
    from aerospike_py import _aerospike as native
    gil = sys._is_gil_enabled()
    ft = bool(sysconfig.get_config_var("Py_GIL_DISABLED"))
    assert (gil,ft) == {"regular":(True,False),"ft":(False,True),"ft_gil":(True,True)}[args.mode]
    data = {"mode":args.mode,"gil":gil,"ft_build":ft,"trial":args.trial,
            "native_sha256":hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest(),
            "root_log_level":logging.getLogger().getEffectiveLevel()}
    diagnostic = hasattr(native,"profile_next_scan")
    assert diagnostic == ("release" not in args.conditions)
    client=await ap.AsyncClient(CONFIG).connect()
    try:
        for c in args.conditions:
            if diagnostic:
                native.profile_next_scan("skip" in c, "detail" in c)
            await scan(client,args.dataset)
            if diagnostic:
                native.profile_next_scan("skip" in c, "detail" in c)
            evidence=await scan(client,args.dataset)
            stages=dict(zip(FIELDS,native.scan_stages(),strict=True)) if diagnostic else {}
            if diagnostic:
                assert stages["rows"]==N and stages["refills"]>=47
                assert stages["conversion_ns"]>0
            print(json.dumps({**data, "condition":c, **evidence, **stages}),flush=True)
    finally:
        await client.close()


def main():
    p=argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--run",nargs=2,type=Path)
    p.add_argument("--mode",choices=["regular","ft","ft_gil"])
    p.add_argument("--conditions",nargs="+")
    p.add_argument("--trial",type=int)
    p.add_argument("--dataset")
    a=p.parse_args()
    if a.mode:
        import uvloop
        assert a.dataset.startswith("prstage_")
        with asyncio.Runner(loop_factory=uvloop.new_event_loop) as r:
            r.run(child(a))
        return
    import aerospike_py as ap
    ds="prstage_"+uuid.uuid4().hex[:12]
    keys=[(NS,ds,i) for i in range(N)]
    with ap.client(CONFIG).connect() as client:
        try:
            for i in range(0,N,500):
                out=client.batch_write([(k,{"v":k[2],"pad":PAD}) for k in keys[i:i+500]])
                assert all(r.result==0 for r in out.batch_records)
            modes=["regular","ft","ft_gil"]
            for trial in range(1,8):
                for mode in modes[trial%3:] + modes[:trial%3]:
                    env=dict(os.environ)
                    if mode=="ft_gil":env["PYTHON_GIL"]="1"
                    else:env.pop("PYTHON_GIL",None)
                    conditions=["trace","skip","trace_detail","skip_detail"]
                    ix=(trial-1)%4
                    conditions=conditions[ix:]+conditions[:ix]
                    builds=[(a.run[0],["release"]),(a.run[1],conditions)]
                    for root, cs in (builds if trial%2 else builds[::-1]):
                        py=root/("gil" if mode=="regular" else "ft")/"bin/python"
                        subprocess.run([str(py),__file__,"--mode",mode,"--dataset",ds,"--trial",str(trial),"--conditions",*cs],
                                       env=env,check=True)
        finally:
            for i in range(0,N,500):
                result=client.batch_remove(keys[i:i+500])
                assert all(r.result in (0,2) for r in result.batch_records)


if __name__=="__main__":main()
