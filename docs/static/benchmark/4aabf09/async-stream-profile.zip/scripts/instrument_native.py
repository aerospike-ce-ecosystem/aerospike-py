"""Apply diagnostic-only probes to a disposable git archive of aerospike-py@4aabf09."""
from pathlib import Path
import sys
root=Path(sys.argv[1])/'rust/src'
def replace(file,old,new):
 p=root/file; s=p.read_text(); assert s.count(old)==1,(file,old);p.write_text(s.replace(old,new))
replace('lib.rs','mod logging;','mod logging;\nmod pr_stage;')
replace('lib.rs','    m.add_function(wrap_pyfunction!(get_metrics_text, m)?)?;','''    m.add_function(wrap_pyfunction!(pr_stage::profile_next_scan, m)?)?;
    m.add_function(wrap_pyfunction!(pr_stage::scan_stages, m)?)?;
    m.add_function(wrap_pyfunction!(get_metrics_text, m)?)?;''')
(root/'pr_stage.rs').write_text('''use pyo3::prelude::*;
use std::sync::atomic::{AtomicBool, AtomicU64, Ordering::Relaxed};
use std::time::Instant;
pub static SKIP: AtomicBool = AtomicBool::new(false);
pub static DETAIL: AtomicBool = AtomicBool::new(false);
pub static BATCH: AtomicU64 = AtomicU64::new(0);
pub static ROWS: AtomicU64 = AtomicU64::new(0);
pub static CALLS: AtomicU64 = AtomicU64::new(0);
pub static TRACE: AtomicU64 = AtomicU64::new(0);
pub static KEY: AtomicU64 = AtomicU64::new(0);
pub static META: AtomicU64 = AtomicU64::new(0);
pub static BINS: AtomicU64 = AtomicU64::new(0);
pub static TUPLE: AtomicU64 = AtomicU64::new(0);

pub fn record(counter: &AtomicU64, since: Option<Instant>) {
    if let Some(start) = since {
        counter.fetch_add(start.elapsed().as_nanos() as u64, Relaxed);
    }
}
#[pyfunction]
pub fn profile_next_scan(skip_trace: bool, detail: bool) {
    for c in [&CALLS, &ROWS, &BATCH, &TRACE, &KEY, &META, &BINS, &TUPLE] {
        c.store(0, Relaxed);
    }
    SKIP.store(skip_trace, Relaxed);
    DETAIL.store(detail, Relaxed);
}
#[pyfunction]
pub fn scan_stages() -> (u64,u64,u64,u64,u64,u64,u64,u64) {
    (CALLS.load(Relaxed), ROWS.load(Relaxed), BATCH.load(Relaxed), TRACE.load(Relaxed),
    KEY.load(Relaxed), META.load(Relaxed), BINS.load(Relaxed), TUPLE.load(Relaxed))
}
''')
replace('types/record.rs','    trace!("Converting Rust record to Python");','''    use crate::pr_stage::{self, record as sample};
    use std::sync::atomic::Ordering::Relaxed;
    use std::time::Instant;
    let detailed = pr_stage::DETAIL.load(Relaxed);
    let start = detailed.then(Instant::now);
    if !pr_stage::SKIP.load(Relaxed) {
        trace!("Converting Rust record to Python");
    }
    sample(&pr_stage::TRACE, start);
    let start = detailed.then(Instant::now);''')
replace('types/record.rs','    let meta = PyDict::new(py);','''    sample(&pr_stage::KEY, start);
    let start = detailed.then(Instant::now);
    let meta = PyDict::new(py);''')
replace('types/record.rs','    let bins = PyDict::new(py);','''    sample(&pr_stage::META, start);
    let start = detailed.then(Instant::now);
    let bins = PyDict::new(py);''')
replace('types/record.rs','    let tuple = PyTuple::new(','    sample(&pr_stage::BINS, start);\n    let start = detailed.then(Instant::now);\n    let tuple = PyTuple::new(')
replace('types/record.rs','    Ok(tuple.into_any().unbind())','    sample(&pr_stage::TUPLE, start);\n    Ok(tuple.into_any().unbind())')
replace('query_stream.rs', '''        let records: Vec<Py<PyAny>> = self
            .0''','''        use crate::pr_stage;
        use std::sync::atomic::Ordering::Relaxed;
        let start = std::time::Instant::now();
        let n = self.0.len();
        let records: Vec<Py<PyAny>> = self
            .0''')
replace('query_stream.rs','''        Ok(PyList::new(py, &records)?.into_any())
    }
}

/// The records of a query''','''        let output = PyList::new(py, &records)?.into_any();
        pr_stage::record(&pr_stage::BATCH, Some(start));
        pr_stage::CALLS.fetch_add(1, Relaxed);
        pr_stage::ROWS.fetch_add(n as u64, Relaxed);
        Ok(output)
    }
}

/// The records of a query''')
