"""Summarize runs collected with profile_stream.py (baseline excludes profilers)."""
import collections
import gzip
import json
from pathlib import Path
import re
import statistics
import sys

directory=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
runs=[json.loads(s) for s in (directory/'profile-runs.jsonl').read_text().splitlines()]
summary=[]
for prod in ('pr','sdk'):
    for gil in (True,False):
        name=f"{prod}-{'gil' if gil else 'ft'}"
        cases=[r for r in runs if r['product']==prod and r['gil']==gil and r['mode']=='plain']
        assert len(cases)==3
        scans=[x for case in cases for x in case['scans']]; assert len(scans)==15
        item={'client':prod,'gil':gil,'n':len(scans)}
        for field in ('wall_ms','cpu_ms','loop_cpu_ms'):
            item['median_'+field]=round(statistics.median(r[field] for r in scans),3)
        item['median_other_cpu_ms']=round(statistics.median(r['cpu_ms']-r['loop_cpu_ms'] for r in scans),3)
        item['mean_cpu_div_wall']=round(sum(r['cpu_ms'] for r in scans)/sum(r['wall_ms'] for r in scans),3)
        groups=set().union(*(c['mean_thread_cpu_ms_by_name'] for c in cases))
        item['median_of_three_mean_thread_groups']={label:round(statistics.median(sum(c['mean_thread_cpu_ms_by_name'].get(label,[0,0])) for c in cases),3) for label in groups}
        cstats=json.loads((directory/f'cprofile-{name}.json').read_text())
        item['profile_counts']={r['name']:r['calls'] for r in cstats if r['name'] in ('scan','visit','__anext__','_next_batch','_iter') or 'next_batch' in r['name']}
        item['logging_getLogger_calls']=max((r['calls'] for r in cstats if r['name']=='getLogger'),default=0)
        stack_file=directory/f'sample-{name}.txt.gz'
        if not stack_file.is_file():
            # Published observations retain native aggregate counts separately.
            archive=directory/'native-stack-counts.json'
            if archive.is_file():
                item.update(json.loads(archive.read_text())[name])
            summary.append(item)
            continue
        text=gzip.open(stack_file,'rt').read()
        callgraph=text.split('Call graph:\n')[1].split('\nTotal number in stack')[0]
        caps=collections.Counter();inc=collections.Counter(); stack=[]; role=''
        regexes={'kevent':r'^kevent','record_to_py':r'record_to_py_inner','native_future':r'batched_future_into_py',
                 'brc':r'_Py_brc','mimalloc_remote_free':r'_mi_free_block_mt','recvfrom':r'__recvfrom',
                 'waker_loop':r'__pyfunction_waker_loop_py','waker_channel_recv':r'std::sync::mpmc::array::Channel.*::recv'}
        for line in callgraph.splitlines():
            root=re.match(r'^\s*([0-9]+) Thread_',line)
            if root:
                role='main' if 'main-thread' in line else 'waker' if 'aerospike-waker' in line else 'workers'
                caps[role]+=int(root[1]);stack=[];continue
            frame=re.match(r'^([ +!:|]*)([0-9]+) (.+?)  \(in ',line)
            if not frame:continue
            depth,num,symbol=len(frame[1]),int(frame[2]),frame[3]
            while stack and stack[-1][0]>=depth:stack.pop()
            for key,rg in regexes.items():
                if re.search(rg,symbol) and not any(re.search(rg,ancestor) for _,ancestor in stack):
                    inc[f'{role}.{key}']+=num
            stack.append((depth,symbol))
        item['native_wall_thread_samples']=dict(caps)
        item['native_wall_selected_inclusive_stacks']=dict(inc)
        summary.append(item)
(directory/'profile-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for item in summary:print(item)
