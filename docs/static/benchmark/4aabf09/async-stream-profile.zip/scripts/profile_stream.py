"""Matched end-to-end stream instrumentation for PR #500 and released official SDK.
Run GIL_PYTHON profile_stream.py --run GIL_PYTHON FT_PYTHON --out <output-dir>.
macOS threading counters use libproc; wall-clock stack samples include parked threads.
"""
import argparse
import asyncio
import collections
import cProfile
import ctypes
import gzip
import hashlib
import json
import os
from pathlib import Path
import pstats
import subprocess
import sys
import time
import uuid

ROWS = 12000
PAD = 'ap' * 80
CHECKSUM = ROWS * (ROWS - 1) // 2 + ROWS * len(PAD)
HOST = os.getenv("AEROSPIKE_HOST", "127.0.0.1")
PORT = int(os.getenv("AEROSPIKE_PORT", 18710))
NS = os.getenv("AEROSPIKE_NAMESPACE", "test")
CONF = {"hosts":[(HOST,PORT)],"cluster_name":os.getenv("AEROSPIKE_CLUSTER_NAME","docker")}


class ThreadInfo(ctypes.Structure):
    _fields_=[('user',ctypes.c_uint64),('system',ctypes.c_uint64),
              ('other',ctypes.c_int32*8),('name',ctypes.c_char*64)]


def counters():
    if sys.platform != 'darwin':
        return {}
    c=ctypes
    info=c.CDLL('/usr/lib/libproc.dylib').proc_pidinfo
    info.argtypes=(c.c_int,c.c_int,c.c_uint64,c.c_void_p,c.c_int)
    ids=(c.c_uint64 * 4096)()
    used=info(os.getpid(),6,0,ids,c.sizeof(ids))
    assert 0 < used < c.sizeof(ids)
    result={}
    for i in range(used//8):
        t=ThreadInfo()
        if info(os.getpid(),5,ids[i],c.byref(t),c.sizeof(t))==c.sizeof(t):
            result[ids[i]]=(t.name.decode() or '(unnamed)',t.user/1e6,t.system/1e6)
    return result


class Consumer:
    def __init__(self):
        self.seen=bytearray(ROWS); self.number=0; self.checksum=0
    def visit(self, bins):
        i,pad=bins['v'],bins['pad']
        if self.seen[i] or i<0 or i>=ROWS or pad!=PAD: raise ValueError('invalid result')
        self.seen[i]=1; self.number+=1; self.checksum+=i+len(pad)
    def verify(self):
        assert self.number==ROWS and self.checksum==CHECKSUM


def child(a):
    import uvloop
    if a.product=='pr':
        import aerospike_py as ap
        from aerospike_py import _aerospike as native
        async def connect():
            c=await ap.AsyncClient(CONF).connect()
            async def scan():
                consumer=Consumer()
                async with c.query(NS,a.dataset).stream() as stream:
                    async for row in stream: consumer.visit(row.bins)
                consumer.verify()
            return scan,c.close
    else:
        import aerospike_native._native as native
        from aerospike_sdk import ClusterDefinition,DataSet,Behavior
        async def connect():
            conn=ClusterDefinition(HOST,PORT).connect()
            c=(await conn.__aenter__()).create_session(Behavior.DEFAULT)
            ds=DataSet.of(NS,a.dataset)
            async def scan():
                consumer=Consumer()
                async with c.query(ds).stream() as stream:
                    async for row in stream: consumer.visit(row.record.bins)
                consumer.verify()
            async def close(): await conn.__aexit__(None,None,None)
            return scan,close
    gil=sys._is_gil_enabled()
    base={'product':a.product,'gil':gil,'trial':a.trial,'build':sys.version.split()[0],'mode':a.mode,
          'rows':ROWS,'checksum':CHECKSUM,'uvloop':uvloop.__version__,
          'sha256':hashlib.sha256(Path(native.__file__).read_bytes()).hexdigest()}
    name=f"{a.product}-{'gil' if gil else 'ft'}"
    with asyncio.Runner(loop_factory=uvloop.new_event_loop) as runner:
        scan,close=runner.run(connect())
        try:
            runner.run(scan())
            if a.mode=='plain':
                before=counters()
                measures=[]
                for i in range(5):
                    start=time.perf_counter_ns(); cpu=time.process_time_ns();loop_cpu=time.thread_time_ns()
                    runner.run(scan())
                    loop_elapsed=time.thread_time_ns()-loop_cpu
                    measures.append({'wall_ms':(time.perf_counter_ns()-start)/1e6,
                                     'cpu_ms':(time.process_time_ns()-cpu)/1e6,'loop_cpu_ms':loop_elapsed/1e6})
                after=counters()
                times=collections.defaultdict(lambda:[0.,0.])
                for tid,(label,u,s) in after.items():
                    old=before.get(tid,(label,0,0))
                    times[label][0]+=(u-old[1])/len(measures);times[label][1]+=(s-old[2])/len(measures)
                print(json.dumps(dict(**base,scans=measures,mean_thread_cpu_ms_by_name=times)))
            elif a.mode=='cprofile':
                p=cProfile.Profile();p.enable()
                runner.run(scan())
                p.disable()
                path=a.out/f'cprofile-{name}.pstats'
                p.dump_stats(str(path))
                rows=[]
                for (filename,line,func),(primitive,calls,self_time,cumulative,callers) in pstats.Stats(p).stats.items():
                    rows.append(dict(file=filename,line=line,name=func,calls=calls,primitive=primitive,
                                     self_ms=round(1000*self_time,5),cum_ms=round(1000*cumulative,5)))
                (a.out/f'cprofile-{name}.json').write_text(json.dumps(sorted(rows,key=lambda r:-r['self_ms']),indent=2))
                print(json.dumps(base))
            else:
                raw=a.out/f'sample-{name}.txt'
                proc=subprocess.Popen(['/usr/bin/sample',str(os.getpid()),'2','2','-file',str(raw)],
                                      stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
                start=time.perf_counter();count=0
                while proc.poll() is None or time.perf_counter()-start<2.6:
                    runner.run(scan());count+=1
                    if time.perf_counter()-start>20: raise RuntimeError('sample exceeded deadline')
                note=proc.communicate()[0].decode()
                if proc.returncode: raise RuntimeError(note)
                with gzip.open(str(raw)+'.gz','wb') as f: f.write(raw.read_bytes())
                raw.unlink()
                print(json.dumps(dict(**base,scans_during_sampling=count,message=note.strip())))
        finally: runner.run(close())


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--run',nargs=2)
    p.add_argument('--out',type=Path,required=True)
    p.add_argument('--mode',choices=['plain','sample','cprofile'])
    p.add_argument('--product')
    p.add_argument('--dataset')
    p.add_argument('--trial',type=int,default=1)
    a=p.parse_args()
    if not a.run: return child(a)
    import aerospike_py as ap
    a.out.mkdir(exist_ok=True)
    name='pr5prof_'+uuid.uuid4().hex[:14]
    with ap.client(CONF).connect() as c:
        try:
            for i in range(0,ROWS,500):
                rr=c.batch_write([((NS,name,j),{'v':j,'pad':PAD}) for j in range(i,i+500)])
                assert all(r.result==0 for r in rr.batch_records)
            cases=[(a.run[0],'pr'),(a.run[1],'sdk'),(a.run[0],'sdk'),(a.run[1],'pr')]
            with (a.out/'profile-runs.jsonl').open('x') as f:
                for mode in (('plain','cprofile','sample') if sys.platform == 'darwin' else ('plain','cprofile')):
                    for j in range(3 if mode=='plain' else 1):
                        for interp,prod in (cases if j%2==0 else cases[::-1]):
                            result=subprocess.run([interp,__file__,'--mode',mode,'--product',prod,'--dataset',name,
                                                   '--out',str(a.out),'--trial',str(j+1)],check=True,text=True,capture_output=True)
                            print(result.stdout.strip(),file=f,flush=True)
        finally:
            for i in range(0,ROWS,500):
                rr=c.batch_remove([(NS,name,j) for j in range(i,i+500)])
                assert all(r.result in (0,2) for r in rr.batch_records)


if __name__=='__main__':main()
