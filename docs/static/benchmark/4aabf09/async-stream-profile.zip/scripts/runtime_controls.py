"""Factorial GIL / completion wake and SDK adapter controls for a single async iterator.

Usage: python runtime_controls.py run /normal/python /ft/python --output runtime.jsonl
Run on an otherwise idle server with a writable test namespace.
"""

import argparse
import asyncio
import json
import os
from pathlib import Path
import random
import subprocess
import sys
import sysconfig
import time
import uuid


N = 12_000
PAD = "ap" * 80
NS = os.environ.get("AEROSPIKE_NAMESPACE", "test")
CONFIG = {"hosts": [(os.environ.get("AEROSPIKE_HOST", "127.0.0.1"), int(os.environ.get("AEROSPIKE_PORT", "18710")))]}


def workload(args):
    import uvloop
    if args.client == "pr":
        import aerospike_py as ap
    else:
        from aerospike_sdk import Behavior, ClusterDefinition, DataSet
    ft = bool(sysconfig.get_config_var("Py_GIL_DISABLED"))
    gil = sys._is_gil_enabled()
    assert (ft, gil) == {"stock": (False, True), "ft-on": (True, True), "ft-off": (True, False)}[args.mode]

    async def run():
        if args.client == "pr":
            c = await ap.AsyncClient(CONFIG).connect()
            stream = lambda: c.query(NS, args.setname).stream()
            close = c.close
        else:
            ctx = ClusterDefinition(*CONFIG["hosts"][0]).connect()
            c = (await ctx.__aenter__()).create_session(Behavior.DEFAULT)
            ds = DataSet.of(NS, args.setname)
            stream = lambda: c.query(ds).stream()
            close = lambda: ctx.__aexit__(None, None, None)

        def verify(bins, seen):
            idx = bins["v"]
            assert 0 <= idx < N and not seen[idx] and bins["pad"] == PAD
            seen[idx] = 1
            return idx + len(bins["pad"])

        try:
            for measured in (False, True):
                seen = bytearray(N)
                count = checksum = 0
                start = time.perf_counter_ns()
                proc, loop = time.process_time_ns(), time.thread_time_ns()
                async with stream() as records:
                    if args.client == "pr":
                        async for row in records:
                            checksum += verify(row.bins, seen)
                            count += 1
                    elif args.access == "sdk":
                        async for row in records:
                            checksum += verify(row.record.bins, seen)
                            count += 1
                    else:
                        # Keep the SDK's own statement, policy, recordset and close path.
                        # Bypass only its per-row async generator and RecordResult.
                        recordset = records._closeable
                        if args.access == "native-count" and measured:
                            async for row in recordset:
                                count += 1
                        else:
                            async for row in recordset:
                                checksum += verify(row.bins, seen)
                                count += 1
                wall = (time.perf_counter_ns() - start) / 1e6
                cpu = (time.process_time_ns() - proc) / 1e6
                loop_cpu = (time.thread_time_ns() - loop) / 1e6
                assert count == N
                count_only = args.access == "native-count" and measured
                if not count_only:
                    assert all(seen) and checksum == N * (N - 1) // 2 + N * len(PAD)
                if measured:
                    print(json.dumps({"client": args.client, "access": args.access, "mode": args.mode,
                                      "gil": gil, "ft_build": ft, "wake": os.environ.get("AEROSPIKE_PIPE_WAKE", "auto"),
                                      "trial": args.trial, "records": count, "checksum": None if count_only else checksum,
                                      "wall_ms": wall, "cpu_ms": cpu, "loop_cpu_ms": loop_cpu}))
        finally:
            await close()

    with asyncio.Runner(loop_factory=uvloop.new_event_loop) as runner:
        runner.run(run())


def drive(args):
    import aerospike_py as ap
    own_set = "wake500_" + uuid.uuid4().hex[:12]
    c = ap.client(CONFIG).connect()
    keys = [(NS, own_set, i) for i in range(N)]
    # All combinations of the transport and actual GIL state. Also measure shipped
    # defaults and the same native recordset with fewer Python adapter layers.
    configurations = [("sdk", mode, wake, "sdk") for mode in ("stock", "ft-on", "ft-off") for wake in ("0", "1")]
    for mode in ("stock", "ft-off"):
        configurations.extend(("sdk", mode, "auto", access) for access in ("sdk", "native", "native-count"))
    configurations.extend(("pr", mode, "auto", "pr") for mode in ("stock", "ft-on", "ft-off"))
    try:
        for i in range(0, N, 400):
            result = c.batch_write([(key, {"v": key[2], "pad": PAD}) for key in keys[i:i+400]])
            assert all(r.result == 0 for r in result.batch_records)
        with args.output.open("x") as out:
            orders = list(configurations)
            for trial in range(1, args.trials + 1):
                random.Random(4010 + trial).shuffle(orders)
                for client, mode, wake, access in orders:
                    env = os.environ.copy()
                    env.pop("PYTHON_GIL", None)
                    env.pop("AEROSPIKE_PIPE_WAKE", None)
                    if mode == "ft-on":
                        env["PYTHON_GIL"] = "1"
                    if wake != "auto":
                        env["AEROSPIKE_PIPE_WAKE"] = wake
                    interp = args.gil_python if mode == "stock" else args.ft_python
                    subprocess.run([interp, __file__, "case", own_set, client, mode, access, str(trial)],
                                   check=True, env=env, stdout=out, timeout=40)
        counter = Path(__file__).with_name("sdk_bridge_counts.py")
        with args.output.with_name("sdk-bridge-counts.jsonl").open("x") as counts:
            for interp, runtime_gil in [(args.gil_python, None), (args.ft_python, None), (args.ft_python, "1")]:
                env = os.environ.copy()
                env.pop("AEROSPIKE_PIPE_WAKE", None)
                env.pop("PYTHON_GIL", None)
                if runtime_gil:
                    env["PYTHON_GIL"] = runtime_gil
                subprocess.run([interp, str(counter), "--set-name", own_set, "--count", str(N),
                                "--checksum", str(N * (N - 1) // 2 + N * len(PAD)),
                                "--host", CONFIG["hosts"][0][0], "--port", str(CONFIG["hosts"][0][1]),
                                "--namespace", NS], check=True, stdout=counts, timeout=40, env=env)
    finally:
        try:
            for i in range(0, N, 400):
                c.batch_remove(keys[i:i+400])
        finally:
            c.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    driver = commands.add_parser("run")
    driver.add_argument("gil_python")
    driver.add_argument("ft_python")
    driver.add_argument("--output", type=Path, required=True)
    driver.add_argument("--trials", default=5, type=int)
    case = commands.add_parser("case")
    for name in ("setname", "client", "mode", "access"):
        case.add_argument(name)
    case.add_argument("trial", type=int)
    args = parser.parse_args()
    (drive if args.command == "run" else workload)(args)
