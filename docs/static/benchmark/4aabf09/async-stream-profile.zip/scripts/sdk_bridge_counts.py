"""Count PNC's Future creation and actual bridge delivery during one SDK dataset scan.

Read-only. Pass an existing isolated set, its expected row count and optional checksum.
Designed for the profile fixture with integer 'v' and string 'pad'. This run is
instrumented and deliberately does not produce timing results.
"""

import argparse
import asyncio
from collections import Counter
import json
import os
import sys
import sysconfig
from unittest.mock import patch

from aerospike_sdk import Behavior, ClusterDefinition, DataSet
from aerospike_sdk.record_stream import RecordStream
import uvloop


async def observe(args):
    counts = Counter()
    loop = asyncio.get_running_loop()
    creating = loop.create_future
    scheduling = loop.call_soon_threadsafe
    add_reader = loop.add_reader
    actual_readers = []
    in_iteration = False

    def create_future():
        if in_iteration:
            counts["loop_future_created"] += 1
        return creating()

    def call_soon_threadsafe(callback, *params, **kw):
        if type(callback).__name__ == "CompletionDrainer":
            if in_iteration:
                counts["threadsafe_drainer_submitted"] += 1
            def count_drain(*a):
                if in_iteration:
                    counts["threadsafe_drainer_ran"] += 1
                return callback(*a)
            return scheduling(count_drain, *params, **kw)
        return scheduling(callback, *params, **kw)

    def add_counted_reader(fd, callback, *params):
        actual_readers.append(type(callback).__name__)
        if type(callback).__name__ == "PipeDrainer":
            def count_pipe(*a):
                if in_iteration:
                    counts["pipe_drainer_ran"] += 1
                return callback(*a)
            return add_reader(fd, count_pipe, *params)
        return add_reader(fd, callback, *params)

    class ObservedRecordset:
        def __init__(self, rs):
            self.rs = rs

        def __aiter__(self):
            return self

        def __anext__(self):
            f = self.rs.__anext__()
            counts["native_anext_called"] += 1
            counts["native_future_pending_on_return"] += not f.done()
            return f

        def close(self):
            return self.rs.close()

    original_from = RecordStream._from_pnc_recordset.__func__

    def wrap_recordset(cls, rs):
        return original_from(cls, ObservedRecordset(rs))

    # Patch only this concrete loop instance, preserving its class (__module__
    # == "uvloop") so that PNC picks the same automatic wake transport.
    with (patch.object(loop, "create_future", create_future),
          patch.object(loop, "call_soon_threadsafe", call_soon_threadsafe),
          patch.object(loop, "add_reader", add_counted_reader),
          patch.object(RecordStream, "_from_pnc_recordset", classmethod(wrap_recordset))):
        async with ClusterDefinition(args.host, args.port).connect() as cluster:
            s = cluster.create_session(Behavior.DEFAULT)
            ds = DataSet.of(args.namespace, args.set_name)
            seen = set()
            checksum = 0
            async with s.query(ds).stream() as stream:
                in_iteration = True
                try:
                    async for item in stream:
                        bins = item.record.bins
                        v = bins[args.id_bin]
                        if v in seen:
                            raise ValueError("Duplicate record")
                        seen.add(v)
                        checksum += v + len(bins[args.pad_bin])
                finally:
                    in_iteration = False
    assert len(seen) == args.count
    if args.checksum is not None:
        assert checksum == args.checksum
    assert counts["native_anext_called"] == args.count + 1
    assert counts["loop_future_created"] == counts["native_anext_called"]
    assert counts["threadsafe_drainer_ran"] + counts["pipe_drainer_ran"] >= args.count + 1
    return {"rows":len(seen),"checksum":checksum,"gil":sys._is_gil_enabled(),
            "ft_abi":bool(sysconfig.get_config_var("Py_GIL_DISABLED")),
            "loop_class":f"{type(loop).__module__}.{type(loop).__name__}",
            "pipe_setting":os.getenv("AEROSPIKE_PIPE_WAKE","auto"),"registered_readers":actual_readers,
            "counts":{k:counts[k] for k in ("native_anext_called","native_future_pending_on_return",
                                            "loop_future_created","threadsafe_drainer_submitted",
                                            "threadsafe_drainer_ran","pipe_drainer_ran")}}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--set-name", required=True)
    p.add_argument("--count", type=int, required=True)
    p.add_argument("--checksum", type=int)
    p.add_argument("--id-bin", default="v")
    p.add_argument("--pad-bin", default="pad")
    p.add_argument("--namespace", default="test")
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--port", type=int, default=18710)
    args = p.parse_args()
    with asyncio.Runner(loop_factory=uvloop.new_event_loop) as runner:
        print(json.dumps(runner.run(observe(args))))


if __name__ == "__main__":
    main()
