"""Separate the wall time waiting for a PR refill from consumption of ready rows."""
import argparse
import asyncio
import json
import os
from pathlib import Path
import subprocess
import sys
import sysconfig
import time
import uuid

import aerospike_py as ap
import uvloop
from runtime_controls import N, PAD, NS, CONFIG


async def measure(args):
    client = await ap.AsyncClient(CONFIG).connect()
    ft = bool(sysconfig.get_config_var("Py_GIL_DISABLED"))
    gil = sys._is_gil_enabled()
    assert (ft, gil) == {"stock": (False, True), "ft-on": (True, True), "ft-off": (True, False)}[args.mode]
    try:
        for timed in (False, True):
            visited = bytearray(N)
            checksum = 0
            refills = refill_ns = refill_loop = 0
            t, tc = time.perf_counter_ns(), time.thread_time_ns()
            async with client.query(NS, args.dataset).stream() as stream:
                original = stream._next_batch
                async def tracked():
                    nonlocal refills, refill_ns, refill_loop
                    a, c = time.perf_counter_ns(), time.thread_time_ns()
                    try:
                        return await original()
                    finally:
                        refill_loop += time.thread_time_ns() - c
                        refill_ns += time.perf_counter_ns() - a
                        refills += 1
                stream._next_batch = tracked
                async for row in stream:
                    i, pad = row.bins["v"], row.bins["pad"]
                    assert 0 <= i < N and not visited[i] and pad == PAD
                    visited[i] = 1
                    checksum += i + len(pad)
            loop = (time.thread_time_ns() - tc) / 1e6
            wall = (time.perf_counter_ns() - t) / 1e6
            assert all(visited) and checksum == N * (N - 1) // 2 + N * len(PAD)
            if timed:
                print(json.dumps({"mode":args.mode, "trial":args.trial, "rows":N, "checksum":checksum, "gil":gil, "refills":refills,
                                  "wall_ms":wall, "refill_wall_ms":refill_ns/1e6, "other_wall_ms":wall-refill_ns/1e6,
                                  "loop_cpu_ms":loop, "inside_refill_loop_cpu_ms":refill_loop/1e6,
                                  "other_loop_cpu_ms":loop-refill_loop/1e6}))
    finally:
        await client.close()


def driver(args):
    name = "consume500_" + uuid.uuid4().hex[:12]
    keys = [(NS,name,i) for i in range(N)]
    client = ap.client(CONFIG).connect()
    try:
        for start in range(0,N,400):
            result = client.batch_write([(k, {"v":k[2], "pad":PAD}) for k in keys[start:start+400]])
            assert all(r.result==0 for r in result.batch_records)
        with args.output.open("x") as f:
            cases = ["stock", "ft-on", "ft-off"]
            for trial in range(1,8):
                shift = trial % 3
                order = cases[shift:] + cases[:shift]
                for mode in (order if trial%2 else order[::-1]):
                    env=os.environ.copy()
                    env.pop("PYTHON_GIL",None)
                    if mode=="ft-on": env["PYTHON_GIL"]="1"
                    interp = sys.executable if mode=="stock" else args.ft
                    subprocess.run([interp,__file__,"case",name,mode,str(trial)],check=True,stdout=f,env=env,timeout=30)
    finally:
        for start in range(0,N,400):
            client.batch_remove(keys[start:start+400])
        client.close()


if __name__ == "__main__":
    p=argparse.ArgumentParser()
    cmd=p.add_subparsers(dest="cmd", required=True)
    run=cmd.add_parser("run")
    run.add_argument("ft");run.add_argument("output",type=Path)
    one=cmd.add_parser("case")
    one.add_argument("dataset");one.add_argument("mode");one.add_argument("trial",type=int)
    args=p.parse_args()
    if args.cmd=="run": driver(args)
    else: uvloop.run(measure(args))
