"""Aggregate the isolated PR native-stage experiment."""
import csv
from collections import defaultdict
from pathlib import Path
from statistics import median
import json
import sys
p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
groups=defaultdict(list)
rows=[json.loads(l) for l in (p/'pr-native-samples.jsonl').read_text().splitlines()]
for r in rows:
    groups[r['mode'],r['condition']].append(r)
assert len(rows)==105 and all(len(group)==7 for group in groups.values())
out=[]
for mode in ('regular','ft','ft_gil'):
    for cond in ('release','trace','skip','trace_detail','skip_detail'):
        group=groups[mode,cond]
        rec={'mode':mode,'condition':cond,'trials':len(group)}
        for fld in ('wall_ms','process_cpu_ms','refills','rows','conversion_ns','trace_ns','key_ns','meta_ns','bins_ns','tuple_ns'):
            vals=[x[fld] for x in group if fld in x]
            name=fld.replace('_ns','_ms')
            rec[name]=round(median(vals)/(1e6 if fld.endswith('_ns') else 1),4) if vals else None
        rec['wall_range_ms']=f"{min(x['wall_ms'] for x in group):.2f}..{max(x['wall_ms'] for x in group):.2f}"
        out.append(rec)
with (p/'pr-native-summary.csv').open('w') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
for row in out:
    print(row['mode'],row['condition'],'wall/cpu/conv',row['wall_ms'],row['process_cpu_ms'],row['conversion_ms'],'trace/key/meta/bin/tuple',*[row[k+'_ms'] for k in ('trace','key','meta','bins','tuple')],row['wall_range_ms'])
