"""Change only the Python iterator refill limit; a separate scan observes actual native awaits.

Usage: python pr_batch_probe.py --run /path/to/gil/python /path/to/ft/python > pr-batch-samples.jsonl
PR 4aabf09 release wheels, CE 8.2. The driver writes/deletes only its own 12,000 integer keys.
Tracked (instrumented) scans are separate from warmup and reported wall/CPU timings.
"""
import argparse
import asyncio
from collections import Counter
from hashlib import sha256
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import sysconfig
import time
import uuid

N = 12_000
PAD = "ap" * 80
NS = os.getenv("AEROSPIKE_NAMESPACE", "test")
CONFIG = {"hosts": [(os.getenv("AEROSPIKE_HOST", "127.0.0.1"), int(os.getenv("AEROSPIKE_PORT", "18710")))],
          "cluster_name": os.getenv("AEROSPIKE_CLUSTER_NAME", "docker")}


class FutureProbe:
    """An observer for successful asyncio Future awaits in this diagnostic scan."""
    def __init__(self, future, owner):
        self.future = future
        self.owner = owner

    def __await__(self):
        for waiter in self.future.__await__():
            self.owner.suspensions += 1
            yield waiter
        rows = self.future.result()
        if rows is None:
            self.owner.eof += 1
        else:
            self.owner.batches[len(rows)] += 1
        return rows


class NativeProbe:
    def __init__(self, inner):
        self.inner = inner
        self.batches = Counter()
        self.eof = 0
        self.suspensions = 0

    def __getattr__(self, name):
        return getattr(self.inner, name)

    def next_batch(self, max_records):
        return FutureProbe(self.inner.next_batch(max_records), self)


async def scan(client, dataset, cap, *, observe=False, raw=False):
    from aerospike_py import _async_client as wrapper

    seen = bytearray(N)
    checksum = 0
    count = 0
    original = wrapper._wrap_record
    if raw:
        wrapper._wrap_record = lambda row: row
    try:
        start, start_cpu = time.perf_counter_ns(), time.process_time_ns()
        async with client.query(NS, dataset).stream() as stream:
            stream._BATCH = cap
            if observe:
                inner = NativeProbe(stream._inner)
                stream._inner = inner
            async for row in stream:
                bins = row[2]
                key, payload = bins["v"], bins["pad"]
                if key < 0 or key >= N or seen[key] or payload != PAD:
                    raise AssertionError("invalid or duplicate record")
                seen[key] = 1
                checksum += key + len(payload)
                count += 1
        elapsed = (time.perf_counter_ns() - start)/1e6
        cpu = (time.process_time_ns() - start_cpu)/1e6
    finally:
        wrapper._wrap_record = original
    assert count == N and checksum == 73_914_000
    if observe:
        assert sum(k * v for k, v in inner.batches.items()) == N and inner.eof == 1
        return {"nonempty_refills": sum(inner.batches.values()), "eof_refills": inner.eof,
                "native_future_yields": inner.suspensions,
                "histogram_rows_per_refill": dict(sorted(inner.batches.items()))}
    return {"wall_ms": elapsed, "process_cpu_ms": cpu, "rows": count, "checksum": checksum}


async def child(args, target, ap):
    client = await ap.AsyncClient(CONFIG).connect()
    try:
        for mode in args.modes:
            size, raw = (256, True) if mode == "raw" else (int(mode), False)
            await scan(client, target, size, raw=raw)
            timed = await scan(client, target, size, raw=raw)
            diag = await scan(client, target, size, raw=raw, observe=True)
            print(json.dumps({"python": platform.python_version(), "gil": sys._is_gil_enabled(),
                              "free_build": bool(sysconfig.get_config_var("Py_GIL_DISABLED")),
                              "native_sha256": args.native_sha, "mode": mode, "trial": args.trial, **timed, **diag}),
                  flush=True)
    finally:
        await client.close()


def run(args):
    import aerospike_py as ap
    from aerospike_py import _aerospike, _async_client
    import uvloop
    assert _async_client.AsyncRecordStream._BATCH == 256
    if args.trial:
        assert args.dataset.startswith("prcap_")
        args.native_sha = sha256(Path(_aerospike.__file__).read_bytes()).hexdigest()
        with asyncio.Runner(loop_factory=uvloop.new_event_loop) as runner:
            runner.run(child(args, args.dataset, ap))
        return
    if args.run is None:
        raise ValueError("supply the two benchmark interpreters")
    dataset = "prcap_" + uuid.uuid4().hex[:12]
    keys = [(NS, dataset, i) for i in range(N)]
    with ap.client(CONFIG).connect() as client:
        try:
            for i in range(0, N, 500):
                out = client.batch_write([(k, {"v": k[2], "pad": PAD}) for k in keys[i:i+500]])
                assert all(r.result == 0 for r in out.batch_records)
            modes = ["1", "16", "64", "256", "raw"]
            # Five orders; each mode occupies each position once per interpreter.
            for trial in range(1, 6):
                offset = 2 * (trial - 1) % len(modes)
                order = modes[offset:] + modes[:offset]
                for interp in (args.run if trial % 2 else args.run[::-1]):
                    subprocess.run([interp, __file__, "--trial", str(trial), "--dataset", dataset,
                                    "--modes", *order], check=True)
        finally:
            for i in range(0, N, 500):
                result = client.batch_remove(keys[i:i+500])
                assert all(r.result in (0, 2) for r in result.batch_records)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--run", nargs=2)
    parser.add_argument("--trial", type=int, default=0)
    parser.add_argument("--dataset")
    parser.add_argument("--modes", nargs="*")
    run(parser.parse_args())
