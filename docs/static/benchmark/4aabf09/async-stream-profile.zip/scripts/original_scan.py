"""Original 12,000-row scan workload, restricted to its public async iterator conditions.
Use a PR interpreter to seed data and pass --run GIL_PYTHON FT_PYTHON.
Each interpreter must have the measured PR build, official SDK, and uvloop.
"""

import argparse
import asyncio
import hashlib
from importlib import metadata
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import sysconfig
import time
import uuid

NS = os.getenv("AEROSPIKE_NAMESPACE", "test")
HOST = os.getenv("AEROSPIKE_HOST", "127.0.0.1")
PORT = int(os.getenv("AEROSPIKE_PORT", "18710"))
CONFIG = {"hosts": [(HOST, PORT)], "cluster_name": os.getenv("AEROSPIKE_CLUSTER_NAME", "docker")}
COUNT = 12_000
PAD = "ap" * 80
WINDOW = 32
MODES = ("sync_collect", "async_collect", "sync_stream", "async_stream", "async_foreach", "point_window")


class Consumer:
    def __init__(self):
        self.seen = bytearray(COUNT)
        self.number = self.checksum = 0

    def bins(self, bins):
        i, payload = bins["v"], bins["pad"]
        if not 0 <= i < COUNT or self.seen[i] or payload != PAD:
            raise ValueError("missing, duplicate, or wrong payload")
        self.seen[i] = 1
        self.number += 1
        self.checksum += i + len(payload)

    def check(self):
        assert self.number == COUNT and self.checksum == COUNT * (COUNT - 1) // 2 + COUNT * len(PAD)


def measure_scan(op, emit):
    for measured in (False, True):
        c = Consumer()
        start, cpu = time.perf_counter(), time.process_time()
        op(c)
        elapsed, cpu = time.perf_counter() - start, time.process_time() - cpu
        c.check()
        if measured:
            emit(records=c.number, checksum=c.checksum, wall_ms=1000 * elapsed, cpu_ms=1000 * cpu)


async def measure_window(client, dataset, ns, set_name, product, emit, seconds):
    ids = range(WINDOW)
    keys = [(ns, set_name, i) for i in ids] if product in {"old", "pr"} else [dataset.id(i) for i in ids]
    payloads = [{f"f{j}": j + offset for j in range(8)} for offset in (0, 1)]

    async def get():
        if product in {"old", "pr"}:
            return await asyncio.gather(*(client.get(k) for k in keys), return_exceptions=True)
        return await client.get_many(keys)

    async def put(payload):
        if product in {"old", "pr"}:
            out = await asyncio.gather(*(client.put(k, payload) for k in keys), return_exceptions=True)
            assert len(out) == WINDOW and all(x == () for x in out)
        else:
            out = await client.put_many(keys, payload)
            assert len(out) == WINDOW and all(x is None for x in out)

    await put(payloads[0])
    for op in ("get_many", "put_many"):

        async def one(index):
            if op == "put_many":
                await put(payloads[index % 2])
            else:
                out = await get()
                assert len(out) == WINDOW and all(x.bins == payloads[0] for x in out)

        for i in range(8):
            await one(i)
        latencies = []
        start, cpu = time.perf_counter(), time.process_time()
        while time.perf_counter() - start < seconds:
            t = time.perf_counter()
            await one(len(latencies))
            latencies.append((time.perf_counter() - t) * 1000)
        elapsed, cpu = time.perf_counter() - start, time.process_time() - cpu
        ordered = sorted(latencies)
        emit(
            operation=op,
            keys=WINDOW,
            calls=len(latencies),
            elapsed_s=elapsed,
            rows_s=len(latencies) * WINDOW / elapsed,
            cpu_us_row=cpu * 1e6 / (len(latencies) * WINDOW),
            p50_ms=statistics.median(ordered),
            p99_ms=ordered[int(0.99 * len(ordered))],
        )
        if op == "put_many":
            out = await get()
            expected = payloads[(len(latencies) - 1) % 2]
            assert len(out) == WINDOW and all(x.bins == expected for x in out)


def child(args):
    if args.client in {"old", "pr"}:
        import aerospike_py as ap
        from aerospike_py import _aerospike

        module_file = _aerospike.__file__
        packages = ["aerospike-py"]
    else:
        import aerospike_native._native
        from aerospike_sdk import Behavior, DataSet, ClusterDefinition as AsyncCluster
        from aerospike_sdk.sync import ClusterDefinition as SyncCluster

        module_file = aerospike_native._native.__file__
        packages = ["aerospike-sdk", "aerospike-native"]

    if args.mode.startswith("async") or args.mode == "point_window":
        import uvloop
    gil = sys._is_gil_enabled()
    ft = bool(sysconfig.get_config_var("Py_GIL_DISABLED"))
    assert gil != ft
    evidence = dict(
        client=args.client,
        mode=args.mode,
        trial=args.trial,
        python=platform.python_version(),
        gil=gil,
        package={name: metadata.version(name) for name in packages},
        native_sha256=hashlib.sha256(Path(module_file).read_bytes()).hexdigest(),
    )

    def emit(**kwargs):
        print(json.dumps({**evidence, **kwargs}), flush=True)

    if args.mode.startswith("sync"):
        if args.client in {"old", "pr"}:
            with ap.client(CONFIG).connect() as c:

                def scan(consumer):
                    q = c.query(NS, args.set_name)
                    if args.mode.endswith("collect"):
                        for row in q.results():
                            consumer.bins(row.bins)
                    else:
                        q.foreach(lambda r: consumer.bins(r.bins))

                measure_scan(scan, emit)
        else:
            with SyncCluster(HOST, PORT).connect() as cluster:
                session = cluster.create_session(Behavior.DEFAULT)
                dataset = DataSet.of(NS, args.set_name)

                def scan(consumer):
                    q = session.query(dataset)
                    if args.mode.endswith("collect"):
                        with q.execute() as stream:
                            for row in stream.collect():
                                consumer.bins(row.record.bins)
                    else:
                        with q.stream() as stream:
                            for row in stream:
                                consumer.bins(row.record.bins)

                measure_scan(scan, emit)
        return

    with asyncio.Runner(loop_factory=uvloop.new_event_loop) as runner:

        async def connect():
            if args.client in {"old", "pr"}:
                c = await ap.AsyncClient(CONFIG).connect()
                return c, None, c.close
            conn = AsyncCluster(HOST, PORT).connect()
            cluster = await conn.__aenter__()

            async def close():
                await conn.__aexit__(None, None, None)

            return cluster.create_session(Behavior.DEFAULT), DataSet.of(NS, args.set_name), close

        c, ds, close = runner.run(connect())
        try:
            if args.mode == "point_window":
                runner.run(measure_window(c, ds, NS, args.set_name, args.client, emit, args.seconds))
                return

            async def scan(consumer):
                if args.client in {"old", "pr"}:
                    q = c.query(NS, args.set_name)
                    if args.mode.endswith("collect"):
                        for row in await q.results():
                            consumer.bins(row.bins)
                    elif args.mode == "async_foreach":
                        await q.foreach(lambda r: consumer.bins(r.bins))
                    else:
                        async with q.stream() as stream:
                            async for row in stream:
                                consumer.bins(row.bins)
                else:
                    q = c.query(ds)
                    if args.mode.endswith("collect"):
                        async with await q.execute() as stream:
                            for row in await stream.collect():
                                consumer.bins(row.record.bins)
                    else:
                        async with q.stream() as stream:
                            async for row in stream:
                                consumer.bins(row.record.bins)

            measure_scan(lambda consumer: runner.run(scan(consumer)), emit)
        finally:
            runner.run(close())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--run", nargs=2, metavar=("GIL", "FT"))
    p.add_argument("--client", choices=("pr", "sdk", "old"))
    p.add_argument("--mode", choices=MODES)
    p.add_argument("--set-name")
    p.add_argument("--trial", type=int)
    p.add_argument("--seconds", type=float, default=1.5)
    args = p.parse_args()
    if args.client:
        assert args.set_name.startswith("p5sc_")
        child(args)
        return

    import aerospike_py as ap

    assert args.run
    name = "p5sc_" + uuid.uuid4().hex[:12]
    keylist = [(NS, name, i) for i in range(COUNT)]
    with ap.client(CONFIG).connect() as client:
        try:
            for start in range(0, COUNT, 500):
                batch = [(key, {"v": key[2], "pad": PAD}) for key in keylist[start : start + 500]]
                assert all(r.result == 0 for r in client.batch_write(batch).batch_records)
            for trial in range(1, 4):
                for idx, mode in enumerate(MODES):
                    if mode != "async_stream":
                        continue
                    for build in (0, 1) if trial % 2 else (1, 0):
                        order = {"async_stream": ["pr", "sdk"], "async_foreach": ["old", "pr"]}.get(
                            mode, ["old", "sdk", "pr"]
                        )
                        shift = (trial + idx + build) % len(order)
                        for product in order[shift:] + order[:shift]:
                            subprocess.run(
                                [
                                    args.run[build + (2 if product == "old" else 0)],
                                    str(Path(__file__).resolve()),
                                    "--client",
                                    product,
                                    "--trial",
                                    str(trial),
                                    "--mode",
                                    mode,
                                    "--set-name",
                                    name + ("w" if mode == "point_window" else ""),
                                    "--seconds",
                                    str(args.seconds),
                                ],
                                check=True,
                            )
        finally:
            for start in range(0, COUNT, 500):
                assert all(r.result in (0, 2) for r in client.batch_remove(keylist[start : start + 500]).batch_records)
            assert all(
                r.result in (0, 2)
                for r in client.batch_remove([(NS, name + "w", i) for i in range(WINDOW)]).batch_records
            )


if __name__ == "__main__":
    main()
