# Python client comparison at PR #500

Compare the aerospike-py commit `4aabf09` with release 0.14.4 and Aerospike's official `aerospike-sdk`/`aerospike-native` 1.0.0. Read the measurements in `observed/`; scripts in `scripts/` reproduce the same public API workloads. The original wider batch sweep interleaved an additional C client. This bundle contains only the three clients shown on the documentation page. The runner interleaves those three and their supported interpreters.

`batch-summary.csv` includes rows/s, process CPU µs/row, per-batch p50/p99 in ms and the observed throughput range. The source has 126 batch observations (37,819 batch calls). `scan-window-summary.csv` covers the full-set scans and 32-key windows. `point-summary.csv` covers single-caller synchronous reads and writes. Each summary uses the median of three trials. SHA-256 hashes identify the native modules in the batch and scan observations; `environment.json` also records release-wheel and server-image identities.
## Prepare the measured build

Prerequisites are Git, uv with managed CPython downloads, a Rust toolchain supporting the measured checkout, and Docker or Podman for a local database. The async workloads use uvloop on macOS or Linux. The published host was an Apple M4 Pro with 12 cores and 24 GiB of RAM, running a single CE 8.2.0.1 node in a Podman VM with 5 vCPUs and 11,444 MiB. The results include CPU contention between the client and that VM.

Extract this ZIP into its own directory and start a shell there. Run the following blocks in the same shell. They create a fresh run directory under the extraction directory and keep new output separate from the shipped `observed/` files. The benchmark code was measured at the exact commit below. If you already have the repository, set `REPO` to its absolute path before starting. Your docs checkout can remain on a different revision.

```sh
set -eu
BUNDLE=$(pwd -P)
RUN=$(mktemp -d "$BUNDLE/run.XXXXXX")
COMMIT=4aabf09f7ca1911a5ba00a3d668ec799c19ed54c
if [ -z "${REPO:-}" ]; then
    REPO="$RUN/repository"
    git clone --no-checkout https://github.com/aerospike-ce-ecosystem/aerospike-py.git "$REPO"
fi
if ! git -C "$REPO" cat-file -e "$COMMIT^{commit}"; then
    git -C "$REPO" fetch origin refs/pull/500/head
fi
git -C "$REPO" worktree add --detach "$RUN/src" "$COMMIT"
test "$(git -C "$RUN/src" rev-parse HEAD)" = "$COMMIT"
uv python install 3.14.2 3.14.2t

build_pair() {
    SOURCE=$1
    ENVS=$2
    for mode in gil ft; do
        py=3.14.2
        if [ "$mode" = ft ]; then py=3.14.2t; fi
        uv venv "$ENVS/$mode" --python "$py"
        interp="$ENVS/$mode/bin/python"
        uv pip install --python "$interp" numpy==2.5.5 uvloop==0.23.0 aerospike-sdk==1.0.0 aerospike-native==1.0.0
        (cd "$SOURCE" && uvx --from 'maturin>=1.9,<2' maturin build --release --locked -i "$interp" -o "$ENVS/wheels/$mode")
        uv pip install --no-deps --python "$interp" "$ENVS/wheels/$mode"/*.whl
    done
}
mkdir -p "$RUN/results" "$RUN/release"
build_pair "$RUN/src" "$RUN/release"
GIL="$RUN/release/gil/bin/python"
FT="$RUN/release/ft/bin/python"
unset PYTHON_GIL AEROSPIKE_PIPE_WAKE
```

## Start one local server

Use a writable `test` namespace in a dedicated single-node Community Edition server. The commands below advertise a loopback address to the host interpreters and set the cluster name expected by the harness. Select an available port with `AEROSPIKE_PORT` (default 18710); `CONTAINER_ENGINE=podman` selects Podman. If you already have a matching server, export its host, port, namespace and cluster name and skip container creation. Each driver seeds a unique set and removes its own keys after the run.

```sh
ENGINE=${CONTAINER_ENGINE:-docker}
export AEROSPIKE_HOST=127.0.0.1
export AEROSPIKE_PORT=${AEROSPIKE_PORT:-18710}
export AEROSPIKE_NAMESPACE=test AEROSPIKE_CLUSTER=docker AEROSPIKE_CLUSTER_NAME=docker
DB_ID=$("$ENGINE" run -d --rm -p "127.0.0.1:$AEROSPIKE_PORT:3000" \
    -e NAMESPACE=test -e CLUSTER_NAME=docker -e DEFAULT_TTL=2592000 \
    -e ACCESS_PORT="$AEROSPIKE_PORT" \
    -v "$RUN/src/scripts/aerospike.template.conf:/etc/aerospike/aerospike.template.conf:ro" \
    docker.io/library/aerospike:ce-8.2.0.1_1)
until "$ENGINE" exec "$DB_ID" asinfo -v status 2>/dev/null | grep -qw ok; do
    test "$("$ENGINE" inspect -f '{{.State.Running}}' "$DB_ID")" = true
    sleep 1
done
```

Run only one measurement driver at a time on the otherwise idle host. Measurements use three warm trials unless the workload below specifies another design. Use `"$ENGINE" stop "$DB_ID"` after completing the experiments if you created the server above.

## Reproduce the comparison

Install the previous release separately for each interpreter. In the environment holding both the new PR build and the SDK, each benchmark child imports only its selected client.

```sh
for mode in gil ft; do
    py=3.14.2
    if [ "$mode" = ft ]; then py=3.14.2t; fi
    uv venv "$RUN/old-$mode" --python "$py"
    uv pip install --python "$RUN/old-$mode/bin/python" aerospike-py==0.14.4 numpy==2.5.5 uvloop==0.23.0
done
OLD_GIL="$RUN/old-gil/bin/python"
OLD_FT="$RUN/old-ft/bin/python"
S="$BUNDLE/scripts"
R="$RUN/results"
"$GIL" "$S/run_batches.py" "$GIL" "$FT" "$OLD_GIL" "$OLD_FT" "$R/batch-samples.jsonl"
"$GIL" "$S/scan_window.py" --run "$GIL" "$FT" "$OLD_GIL" "$OLD_FT" > "$R/scan-window-samples.jsonl"
"$GIL" "$S/point_compare.py" --old-gil "$OLD_GIL" --old-ft "$OLD_FT" --pr-ft "$FT" --output "$R/point-samples.jsonl"
"$GIL" "$S/summarize_batches.py" "$R"
"$GIL" "$S/summarize_scans.py" "$R/scan-window-samples.jsonl" "$R/scan-window-summary.csv"
"$GIL" "$S/summarize_points.py" "$R"
```

Batch reads validate all eight bins on every one of the 720 rows. Writes send distinct rows, check per-row results and read back the values. The main dictionary-write metric includes request shaping from dictionaries. `write` measures the additional case with API-specific input prepared in advance. The NumPy comparison includes the SDK's row conversion to or from a structured array. Each batch workload is timed for 1.2 s per trial after three warmups. Scans check both bin values, 12,000 distinct IDs and checksum 73,914,000. Independent 32-key requests use a 1.5 s window per trial. Each SDK point window sends independent commands and returns positional results.
