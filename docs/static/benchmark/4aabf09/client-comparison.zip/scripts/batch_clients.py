"""Run one release/API against a caller-owned benchmark set; use the paired driver."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
from importlib import metadata
import json
import operator
import os
from pathlib import Path
import platform
import re
import statistics
import sys
import sysconfig
import threading
import time

import numpy as np

p = argparse.ArgumentParser()
p.add_argument('variant',choices=('pr','old','sdk'))
p.add_argument('set_name')
p.add_argument('trial',type=int)
p.add_argument('--seconds',type=float,default=1.2)
p.add_argument('--cleanup',action='store_true')
args = p.parse_args()
assert re.fullmatch(r'pr500cmp_[a-f0-9]{12}',args.set_name)
own = args.variant in ('pr','old')
if own:
    import aerospike_py as ap
    from aerospike_py import _aerospike as extension
    version=metadata.version('aerospike-py')
else:
    import aerospike_native as extension
    from aerospike_sdk import Behavior,DataSet
    from aerospike_sdk.sync import ClusterDefinition
    version=metadata.version('aerospike-sdk')+' / '+metadata.version('aerospike-native')
gil=sys._is_gil_enabled()
ft=bool(sysconfig.get_config_var('Py_GIL_DISABLED'))
assert gil != ft
BASE=dict(client=args.variant,version=version,trial=args.trial,python=platform.python_version(),gil=gil,ft=ft,
          numpy=np.__version__,module_hash=hashlib.sha256(Path(extension.__file__).read_bytes()).hexdigest())
ns=os.getenv('AEROSPIKE_NAMESPACE','test'); host=os.getenv('AEROSPIKE_HOST','127.0.0.1'); port=int(os.getenv('AEROSPIKE_PORT','18710'))
names=tuple(f'f{i}' for i in range(8))
dtype=np.dtype([(name,'<i8') for name in names]); with_key=np.dtype([('_key','<i8'),*dtype.descr])
getfields=operator.itemgetter(*names)
if own:
    c=ap.client({'hosts':[(host,port)],'cluster_name':os.getenv('AEROSPIKE_CLUSTER','docker')}).connect()
    key=lambda i:(ns,args.set_name,i)
    def read(keys,array):
        h=c.batch_read(keys)
        if array:
            a=h.to_numpy(dtype)
            assert not np.any(a.result_codes)
            return a.batch_records
        return h.to_list()
    prepare=lambda keys,ids,rows:list(zip(keys,rows))
    send=c.batch_write
    def check(out,n):
        assert len(out.batch_records)==n and all(x.result==0 for x in out.batch_records)
    write_array=lambda arr:c.batch_write_numpy(arr,ns,args.set_name,arr.dtype)
    close=c.close
else:
    ctx=ClusterDefinition(host,port).connect()
    session=ctx.__enter__().create_session(Behavior.DEFAULT); ds=DataSet.of(ns,args.set_name); key=ds.id
    def read(keys,array):
        with session.query(*keys).execute() as stream:
            outcomes=stream.collect()
        if array:
            return np.fromiter((getfields(x.record.bins) for x in outcomes),dtype=dtype,count=len(outcomes))
        return [x.record.bins for x in outcomes]
    prepare=lambda keys,ids,rows:[(i,*getfields(row)) for i,row in zip(ids,rows)]
    send=lambda rows:session.upsert(ds).bins(*names).rows(rows).execute()
    def check(out,n):
        with out as stream:
            rows=stream.collect()
            assert len(rows)==n and all(x.is_ok for x in rows)
    write_array=lambda arr:send(arr.tolist())
    close=lambda:ctx.__exit__(None,None,None)

def run():
    windows=[]
    n=720
    for t in range(4):
        ids=list(range(t*1000,t*1000+n)); keys=[key(i) for i in ids]
        vals=[tuple(i*13+j for j in range(8)) for i in ids]
        rows=[dict(zip(names,v)) for v in vals]
        modified=[tuple(x+1 for x in v) for v in vals]
        changed=[dict(zip(names,v)) for v in modified]
        base=prepare(keys,ids,rows); check(send(base),n)
        assert read(keys,False)==rows
        windows.append((ids,keys,rows,changed,base,prepare(keys,ids,changed),np.array([(i,*v) for i,v in zip(ids,modified)],dtype=with_key),sum(sum(v) for v in vals)))
    for nt in (1,4):
        for work in (('read','write') if nt==1 else ('read','write','write_from_dict','numpy_read','numpy_write')):
            def op(t):
                ids,keys,rows,changed,base,update,arr,expected=windows[t]
                if work=='read':
                    ret=read(keys,False)
                    assert len(ret)==n and sum(sum(x.values()) for x in ret)==expected
                elif work=='numpy_read':
                    a=read(keys,True)
                    assert a.shape==(n,) and a.dtype==dtype and int(a.view('<i8').sum())==expected
                elif work=='numpy_write':
                    check(write_array(arr),n)
                elif work=='write_from_dict':
                    check(send(prepare(keys,ids,changed)),n)
                else:
                    check(send(update),n)
            clock={}
            def start():
                clock.update(wall=time.perf_counter(),cpu=time.process_time())
            barrier=threading.Barrier(nt,action=start,timeout=18)
            def worker(t):
                for _ in range(3): op(t)
                barrier.wait()
                samples=[]
                while not samples or time.perf_counter()<clock['wall']+args.seconds:
                    begin=time.perf_counter();op(t)
                    samples.append(time.perf_counter()-begin)
                return samples
            with ThreadPoolExecutor(nt) as pool:
                futures=[pool.submit(worker,t) for t in range(nt)]
                lats=[v for f in futures for v in f.result()]
                wall=time.perf_counter()-clock['wall']; cpu=time.process_time()-clock['cpu']
            if 'write' in work:
                for _,keys,rows,changed,base,*_rest in windows[:nt]:
                    assert read(keys,False)==changed
                    check(send(base),n)
            lats.sort()
            print(json.dumps(dict(**BASE,work=work,threads=nt,keys=n,calls=len(lats),elapsed=wall,
                             rows_s=n*len(lats)/wall,cpu_us_row=cpu/(len(lats)*n)*1e6,
                             p50_ms=1000*statistics.median(lats),p99_ms=1000*lats[min(len(lats)-1,int(.99*len(lats)))])),flush=True)

try:
    if args.cleanup:
        assert args.variant=='pr'
        for t in range(4):
            res=c.batch_remove([key(i) for i in range(t*1000,t*1000+720)])
            assert all(x.result in (0,2) for x in res.batch_records)
    else:
        run()
finally:
    close()
