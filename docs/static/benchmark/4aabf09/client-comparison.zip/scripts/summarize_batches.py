"""Aggregate by client, interpreter, output shape and concurrency; absolute measurements and useful PR ratios."""
from collections import defaultdict
import csv
import json
from pathlib import Path
from statistics import median
import sys

p=Path(sys.argv[1]) if len(sys.argv)>1 else Path(__file__).parent
by=defaultdict(list)
for line in (p/'batch-samples.jsonl').read_text().splitlines():
    row=json.loads(line);by[(row['ft'],row['work'],row['threads'],row['client'])].append(row)
out=[]
for (ft,work,threads,client),series in sorted(by.items()):
    assert {v['trial'] for v in series}=={1,2,3}
    v={'ft':ft,'work':work,'threads':threads,'client':client,'trials':len(series),'calls':sum(r['calls'] for r in series)}
    for field in ('rows_s','cpu_us_row','p50_ms','p99_ms'):
        v[field]=median(x[field] for x in series)
    v['min_rows_s']=min(r['rows_s'] for r in series); v['max_rows_s']=max(r['rows_s'] for r in series)
    out.append(v)
with (p/'batch-summary.csv').open('w',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0]));w.writeheader();w.writerows(out)
idx={(v['ft'],v['work'],v['threads'],v['client']):v for v in out}
with (p/'batch-ratios.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['ft','work','threads','comparator','PR throughput change %','PR CPU/row change %','PR p99 change %','PR higher throughput-pairs'])
    for (ft,work,nt,c),r in sorted(idx.items()):
        if c=='pr':continue
        pr=idx[ft,work,nt,'pr']
        trial=lambda client:{x['trial']:x['rows_s'] for x in by[ft,work,nt,client]}
        wins=sum(v>trial(c)[k] for k,v in trial('pr').items())
        w.writerow([ft,work,nt,c,*[round(100*(pr[m]/r[m]-1),2) for m in ('rows_s','cpu_us_row','p99_ms')],wins])
print('samples',sum(map(len,by.values())),'calls',sum(v['calls'] for v in out))
