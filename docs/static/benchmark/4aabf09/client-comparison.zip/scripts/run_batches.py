"""Arguments are paths to the PR GIL+SDK, PR FT+SDK, 0.14.4 GIL and FT interpreters and output."""
from pathlib import Path
import os
import subprocess
import sys
import uuid

gil,ft,oldgil,oldft,output=sys.argv[1:]
script=Path(__file__).with_name('batch_clients.py')
set_name='pr500cmp_'+uuid.uuid4().hex[:12]
configs=[(gil,'pr'),(gil,'sdk'),(oldgil,'old'),(ft,'pr'),(ft,'sdk'),(oldft,'old')]
orders=[configs,configs[::-1],configs[3:]+configs[:3]]
try:
    with open(output,'x') as f:
        for trial,order in enumerate(orders,1):
            for py,client in order:
                print(f'{trial} {py} {client}',file=sys.stderr,flush=True)
                subprocess.run([py,str(script),client,set_name,str(trial),'--seconds',os.getenv('BENCH_SECONDS','1.2')],stdout=f,check=True)
finally:
    subprocess.run([gil,str(script),'pr',set_name,'0','--cleanup'],check=True)
