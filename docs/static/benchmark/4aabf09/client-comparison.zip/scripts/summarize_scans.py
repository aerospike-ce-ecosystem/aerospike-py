"""Usage: python summarize_scans.py scan-window-samples.jsonl scan-window-summary.csv"""

import csv
import json
import statistics
import sys
from collections import defaultdict
from pathlib import Path

rows = [json.loads(line) for line in Path(sys.argv[1]).read_text().splitlines()]
groups = defaultdict(list)
for row in rows:
    groups[(row["gil"], row.get("operation", row["mode"]), row["client"])].append(row)
summary = []
for (gil, mode, client), cases in sorted(groups.items()):
    assert len(cases) == 3 and {case["trial"] for case in cases} == {1, 2, 3}
    row = {"python": "3.14.2" if gil else "3.14.2t", "mode": mode, "client": client, "trials": len(cases)}
    if "records" in cases[0]:
        assert all(c["records"] == 12_000 and c["checksum"] == 73_914_000 for c in cases)
        row["records_per_scan"] = 12_000
        attrs = ["wall_ms", "cpu_ms"]
    else:
        row["total_calls"] = sum(c["calls"] for c in cases)
        attrs = ["rows_s", "cpu_us_row", "p50_ms", "p99_ms"]
    for attr in attrs:
        row[attr] = round(statistics.median(c[attr] for c in cases), 3)
    summary.append(row)
assert len(rows) == 114 and len(summary) == 38
with open(sys.argv[2], "w", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=[
            "python",
            "mode",
            "client",
            "trials",
            "records_per_scan",
            "wall_ms",
            "cpu_ms",
            "total_calls",
            "rows_s",
            "cpu_us_row",
            "p50_ms",
            "p99_ms",
        ],
    )
    writer.writeheader()
    writer.writerows(summary)
for r in summary:
    print(r["python"], r["mode"], r["client"], r.get("wall_ms", r.get("rows_s")), r.get("cpu_ms", r.get("cpu_us_row")))
