"""One sync caller, 8 integer bins per record, using the previous and current project and the SDK."""

import argparse
import contextlib
import json
import os
from pathlib import Path
import platform
import statistics
import subprocess
import sys
import time
import uuid


@contextlib.contextmanager
def connect(name, host, port, ns, dataset):
    if name == "sdk":
        from aerospike_sdk import Behavior, DataSet
        from aerospike_sdk.sync import ClusterDefinition

        with ClusterDefinition(host, port).connect() as cluster:
            c = cluster.create_session(Behavior.DEFAULT)
            yield DataSet.of(ns, dataset).id, lambda k: c.get(k).bins, c.put
    else:
        import aerospike_py as module
        c = module.client({"hosts": [(host, port)]}).connect()
        try:
            yield lambda i: (ns, dataset, i), lambda k: c.get(k)[2], c.put
        finally:
            c.close()


def child(name, dataset, trial, seconds, host, port, ns):
    with connect(name, host, port, ns, dataset) as (key, get, put):
        gil = sys._is_gil_enabled()
        keys = [key(i) for i in range(64)]
        values = [{f"v{j}": i * 8 + j for j in range(8)} for i in range(len(keys))]
        for k, v in zip(keys, values):
            put(k, v)

        def checked_get(i):
            assert get(keys[i]) == values[i]

        def checked_put(i):
            put(keys[i], values[i])

        for kind, op in [("get", checked_get), ("put", checked_put)]:
            for i in range(64):
                op(i)
            durations = []
            start, cpu = time.perf_counter(), time.process_time()
            while time.perf_counter() - start < seconds:
                t = time.perf_counter()
                op(len(durations) % len(keys))
                durations.append(time.perf_counter() - t)
            end, end_cpu = time.perf_counter(), time.process_time()
            durations.sort()
            print(json.dumps({"client": name, "operation": kind, "trial": trial, "calls": len(durations),
                              "python": platform.python_version(), "gil": gil,
                              "calls_s": len(durations) / (end - start),
                              "cpu_us_call": (end_cpu - cpu) * 1e6 / len(durations),
                              "p50_us": statistics.median(durations) * 1e6,
                              "p99_us": durations[int(.99 * len(durations))] * 1e6}))
            for i in range(64):
                checked_get(i)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    parser.add_argument("--client", choices=["pr", "sdk", "old"])
    parser.add_argument("--pr-ft")
    parser.add_argument("--old-gil")
    parser.add_argument("--old-ft")
    parser.add_argument("--set-name")
    parser.add_argument("--trial", type=int)
    parser.add_argument("--seconds", type=float, default=1.2)
    args = parser.parse_args()
    ns = os.getenv("AEROSPIKE_NAMESPACE", "test")
    host = os.getenv("AEROSPIKE_HOST", "127.0.0.1")
    port = int(os.getenv("AEROSPIKE_PORT", "18710"))
    if args.client:
        child(args.client, args.set_name, args.trial, args.seconds, host, port, ns)
        return
    import aerospike_py
    name = "point500_" + uuid.uuid4().hex[:12]
    try:
        with args.output.open("x") as out:
            cases = [(sys.executable, "pr"), (args.old_gil, "old"), (sys.executable, "sdk"),
                     (args.pr_ft, "pr"), (args.old_ft, "old"), (args.pr_ft, "sdk")]
            for trial, order in enumerate([cases, cases[::-1], cases[2:] + cases[:2]], 1):
                for interp, client in order:
                    subprocess.run([interp, __file__, "--client", client, "--trial", str(trial),
                                    "--set-name", name, "--seconds", str(args.seconds)], check=True, stdout=out)
    finally:
        c = aerospike_py.client({"hosts": [(host, port)]}).connect()
        try:
            c.batch_remove([(ns, name, i) for i in range(64)])
        finally:
            c.close()


if __name__ == "__main__":
    main()
