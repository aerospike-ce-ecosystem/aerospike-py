"""Summarize the synchronous point loop in a directory containing point-samples.jsonl."""
from collections import defaultdict
from pathlib import Path
from statistics import median
import csv
import json
import sys

p = Path(sys.argv[1])
groups = defaultdict(list)
for line in (p/'point-samples.jsonl').read_text().splitlines():
    row = json.loads(line)
    groups[row['gil'],row['operation'],row['client']].append(row)
assert len(groups) == 12
with (p/'point-summary.csv').open('w', newline='') as f:
    writer = csv.writer(f)
    fields = ['calls_s','cpu_us_call','p50_us','p99_us']
    writer.writerow(['gil','operation','client','trials',*fields])
    for key, rows in sorted(groups.items()):
        assert {r['trial'] for r in rows} == {1,2,3}
        writer.writerow([*key,len(rows),*[round(median(r[k] for r in rows),3) for k in fields]])
