"""Join the sampled application and native spans by their trace and parent IDs."""
import argparse
from collections import defaultdict
import csv
import json
from pathlib import Path
from statistics import median


def index_native(path):
    by_parent = defaultdict(list)
    for line in path.read_text().splitlines():
        row = json.loads(line)
        by_parent[(row["trace_id"], row["parent"])].append(row)
    return by_parent


def summary(folder):
    native = index_native(folder / "native.jsonl")
    rows = []
    for path in sorted(folder.glob("*-pr-*.json")) + sorted(folder.glob("*-old-*.json")) + sorted(folder.glob("*-sdk-*.json")):
        r = json.loads(path.read_text())
        parents = [p for p in r["app_spans"] if p["name"] == "bench.batch_read"]
        spans = [s for p in parents for s in native[(p["trace_id"], p["id"])] if s["name"] == "BATCH_READ"]
        durations = [(s["end"] - s["start"]) * 1e-6 for s in spans]
        app_phase = r["phase_p50_ms"]
        stages = r["stage_metrics"]
        rows.append({
            "mode": path.name.split("-")[0], "api": r["api"], "product": r["product"],
            "keys": r["keys"], "input_keys": r.get("input_keys"), "trial_file": path.name,
            "calls": r["calls"], "sampled_app_parents": len(parents),
            "matched_native_spans": len(spans), "native_span_p50_ms": median(durations) if durations else None,
            "total_p50_ms": app_phase.get("total_ns"),
            "submit_and_return_p50_ms": app_phase.get("submit_and_await_ns"),
            "envelope_p50_ms": app_phase.get("envelope_ns"), "convert_p50_ms": app_phase.get("convert_ns"),
            "native_io_mean_ms": stages.get("io", {}).get("mean_ms"),
            "key_parse_mean_ms": stages.get("key_parse", {}).get("mean_ms"),
            "numpy_mean_ms": stages.get("to_numpy", {}).get("mean_ms"),
            "key_index_mean_ms": stages.get("key_index", {}).get("mean_ms"),
            "into_pyobject_mean_ms": stages.get("into_pyobject", {}).get("mean_ms"),
            "spawn_blocking_delay_mean_ms": stages.get("spawn_blocking_delay", {}).get("mean_ms"),
        })
    if not rows:
        raise ValueError("no completed diagnostic cases")
    with (folder / "trace-summary.csv").open("x") as output:
        writer = csv.DictWriter(output, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(sorted(rows, key=lambda r: (r["mode"], r["api"], r["product"], r["keys"])))
    print(f"{len(rows)} cases, {sum(r['matched_native_spans'] for r in rows)} matched native child spans")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("folder", type=Path)
    summary(parser.parse_args().folder)
