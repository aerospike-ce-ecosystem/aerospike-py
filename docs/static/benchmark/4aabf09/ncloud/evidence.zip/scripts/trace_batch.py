"""Collect bounded OTLP and stage measurements on the dedicated Linux load VM.

The reference matrix runs without diagnostics. This process uses sampled
application spans and a separate loopback OTLP receiver. Run it serially
between matrix runs on the same DB and with the matrix fixture name.
"""
import argparse
import asyncio
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import json
import os
from pathlib import Path
import re
import statistics
import sys
import time


def collect(args):
    import grpc
    from opentelemetry.proto.collector.trace.v1 import trace_service_pb2 as pb
    from opentelemetry.proto.collector.trace.v1 import trace_service_pb2_grpc as rpc

    class Collector(rpc.TraceServiceServicer):
        def Export(self, request, context):
            for record in request.resource_spans:
                for scope in record.scope_spans:
                    for span in scope.spans:
                        output.write(json.dumps({
                            "name": span.name.split(" ", 1)[0], "scope": scope.scope.name,
                            "trace_id": span.trace_id.hex(), "id": span.span_id.hex(),
                            "parent": span.parent_span_id.hex(), "start": span.start_time_unix_nano,
                            "end": span.end_time_unix_nano, "status": span.status.code,
                        }) + "\n")
            return pb.ExportTraceServiceResponse()

    with args.out.open("x", buffering=1) as output:
        # One worker preserves contiguous output and is adequate for sampled diagnostics.
        server = grpc.server(ThreadPoolExecutor(max_workers=1))
        rpc.add_TraceServiceServicer_to_server(Collector(), server)
        port = server.add_insecure_port(f"127.0.0.1:{args.port}")
        if not port:
            raise RuntimeError("cannot bind local OTLP listener")
        server.start()
        args.ready.write_text(str(port) + "\n")
        try:
            server.wait_for_termination(timeout=1200)
        finally:
            server.stop(grace=5).wait()


def stage_snapshot(ap):
    data = {}
    for line in ap.get_metrics().splitlines():
        match = re.match(r'^db_client_internal_stage_seconds_(count|sum)\{(.*?)\}\s+([^ ]+)', line)
        if match:
            kind, raw, value = match.groups()
            attrs = dict(re.findall(r'(\w+)="([^"]*)"', raw))
            if attrs.get("db_operation_name") == "batch_read":
                data.setdefault(attrs["stage"], {})[kind] = float(value)
    return data


def stage_delta(ap, before):
    result = {}
    for k, data in stage_snapshot(ap).items():
        n = data["count"] - before.get(k, {}).get("count", 0)
        if n:
            value = data["sum"] - before.get(k, {}).get("sum", 0)
            result[k] = {"samples": int(n), "mean_ms": value * 1000 / n}
    return result


@contextmanager
def instrumentation(product, port):
    os.environ["OTEL_TRACES_EXPORTER"] = "otlp"
    os.environ["OTEL_SDK_DISABLED"] = "false"
    os.environ["OTEL_TRACES_SAMPLER"] = "parentbased_traceidratio"
    os.environ["OTEL_TRACES_SAMPLER_ARG"] = "0.125"
    os.environ["OTEL_BSP_SCHEDULE_DELAY"] = "250"
    endpoint = f"http://127.0.0.1:{port}"
    os.environ["OTEL_EXPORTER_OTLP_ENDPOINT"] = endpoint
    os.environ["OTEL_EXPORTER_OTLP_TRACES_ENDPOINT"] = endpoint
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import SimpleSpanProcessor
    from opentelemetry.sdk.trace.export.in_memory_span_exporter import InMemorySpanExporter
    from opentelemetry.sdk.trace.sampling import ParentBased, TraceIdRatioBased

    provider = TracerProvider(sampler=ParentBased(TraceIdRatioBased(0.125)))
    exporter = InMemorySpanExporter()
    provider.add_span_processor(SimpleSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    ap = None
    if product == "pr":
        import aerospike_py as ap
        ap.init_tracing()
        ap.set_internal_stage_metrics_enabled(True)
    try:
        yield provider.get_tracer("batch-diagnostic"), exporter, ap
    finally:
        if ap is not None:
            ap.shutdown_tracing()
        provider.shutdown()


def config_for(args):
    return {"hosts": [(args.host, args.port)], "cluster_name": args.cluster}


def sync_reads(args, tracer, config, rows):
    from fixed_rate import open_reader
    with open_reader(args.product, args.dataset, args.output, config) as (make_key, read, _version):
        keys = [make_key(i) for i in range(args.keys)]
        for _ in range(5):
            assert len(read(keys)) == len(keys)
        start = time.perf_counter()
        period = args.keys / args.rows_s
        for i in range(args.calls):
            wake = start + i * period - time.perf_counter()
            if wake > 0:
                time.sleep(wake)
            phases = {}
            with tracer.start_as_current_span("bench.batch_read") as parent:
                parent.set_attribute("bench.keys", args.keys)
                start_ns = time.perf_counter_ns()
                result = read(keys, phases=phases)
                assert len(result) == len(keys)
                del result
                total = time.perf_counter_ns() - start_ns
                for k, v in phases.items():
                    parent.set_attribute("bench." + k, v)
                rows.append({"total_ns": total, **phases})


async def async_pr_reads(args, tracer, config, rows, ap):
    import numpy as np
    client = await ap.AsyncClient(config).connect()
    ns = os.getenv("DB_NAMESPACE", "test")
    keys = [(ns, args.dataset, i) for i in range(args.keys)]
    dtype = np.dtype([(f"f{i}", "i8") for i in range(8)])
    policy = {"socket_timeout": 5000, "total_timeout": 10000, "max_retries": 0}
    try:
        first = await client.batch_read(keys, policy=policy)
        if args.prepared_digest:
            resolved = [tuple(row.key) for row in first.batch_records]
            if len(resolved) != len(keys) or any(k[:3] != key or len(k[3]) != 20 for k, key in zip(resolved, keys)):
                raise ValueError("server results did not expose matching trusted digests")
            keys = resolved
            first = await client.batch_read(keys, policy=policy)
        if [int(row["f0"]) for row in first.to_numpy(dtype).batch_records] != [i * 8 for i in range(args.keys)]:
            raise ValueError("fixture or prepared keys did not return the expected rows")
        del first
        before = stage_snapshot(ap)
        start = time.perf_counter()
        period = args.keys / args.rows_s
        for i in range(args.calls):
            if (wake := start + i * period - time.perf_counter()) > 0:
                await asyncio.sleep(wake)
            with tracer.start_as_current_span("bench.batch_read") as parent:
                parent.set_attribute("bench.keys", args.keys)
                start_ns = time.perf_counter_ns()
                handle = await client.batch_read(keys, policy=policy)
                returned = time.perf_counter_ns()
                with tracer.start_as_current_span("bench.materialize"):
                    if args.output == "numpy":
                        arr = handle.to_numpy(dtype)
                        assert len(arr.batch_records) == args.keys and not arr.result_codes.any()
                        del arr
                    else:
                        lst = handle.to_list()
                        assert len(lst) == args.keys
                        del lst
                    del handle
                end = time.perf_counter_ns()
                rows.append({"total_ns": end - start_ns, "submit_and_await_ns": returned - start_ns,
                             "convert_ns": end - returned})
    finally:
        await client.close()
    return stage_delta(ap, before)


def diagnose(args):
    rows = []
    with instrumentation(args.product, args.otlp_port) as (tracer, exporter, ap):
        if args.api == "async":
            if args.product != "pr":
                raise ValueError("async internal-stage probe requires PR")
            hist = asyncio.run(async_pr_reads(args, tracer, config_for(args), rows, ap))
        else:
            before = stage_snapshot(ap) if ap else None
            sync_reads(args, tracer, config_for(args), rows)
            hist = stage_delta(ap, before) if ap else {}
        spans = []
        for p in exporter.get_finished_spans():
            spans.append({"name": p.name, "trace_id": f"{p.context.trace_id:032x}",
                          "id": f"{p.context.span_id:016x}", "parent": f"{p.parent.span_id:016x}" if p.parent else "",
                          "start": p.start_time, "end": p.end_time})
    fields = {k for r in rows for k in r}
    info = {
        "product": args.product, "api": args.api, "keys": args.keys, "output": args.output,
        "input_keys": "prepared_digest" if args.prepared_digest else "ordinary_tuple",
        "gil_enabled": sys._is_gil_enabled(), "requested_rows_s": args.rows_s, "calls": len(rows),
        "phase_p50_ms": {k: statistics.median(r[k] for r in rows if k in r) / 1e6 for k in sorted(fields)},
        "stage_metrics": hist, "app_spans": spans, "observations": rows,
    }
    with args.out.open("x") as f:
        json.dump(info, f, indent=2)
        f.write("\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    server = commands.add_parser("collect")
    server.add_argument("--port", type=int, default=0)
    server.add_argument("--ready", required=True, type=Path)
    server.add_argument("--out", required=True, type=Path)
    run = commands.add_parser("run")
    run.add_argument("--product", required=True, choices=["old", "pr", "sdk"])
    run.add_argument("--api", choices=["sync", "async"], default="sync")
    run.add_argument("--keys", type=int, choices=[500, 1000, 2000], required=True)
    run.add_argument("--calls", type=int, default=160, choices=range(10, 501), metavar="10..500")
    run.add_argument("--rows-s", type=float, default=90000)
    run.add_argument("--output", default="numpy", choices=["dict", "numpy"])
    run.add_argument("--prepared-digest", action="store_true")
    run.add_argument("--dataset", required=True)
    run.add_argument("--host", default=os.getenv("DB_HOST"))
    run.add_argument("--port", type=int, default=int(os.getenv("DB_PORT", "3000")))
    run.add_argument("--cluster", default=os.getenv("DB_CLUSTER", "equalrate"))
    run.add_argument("--otlp-port", type=int, required=True)
    run.add_argument("--out", required=True, type=Path)
    args = parser.parse_args()
    if args.command == "collect":
        collect(args)
    else:
        if not args.host or not 0 < args.rows_s <= 2_000_000:
            parser.error("supply a valid host and bounded rows/s")
        if args.prepared_digest and (args.product != "pr" or args.api != "async"):
            parser.error("the prepared digest control uses the PR async client")
        diagnose(args)
