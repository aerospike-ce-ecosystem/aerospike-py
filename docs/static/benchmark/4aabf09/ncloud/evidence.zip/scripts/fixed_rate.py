"""Run reproducible, fixed-arrival-rate synchronous Aerospike batch comparisons."""

from __future__ import annotations

import argparse
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import csv
from datetime import datetime, timedelta, timezone
import hashlib
from importlib.metadata import version
import ipaddress
import json
import math
import operator
import os
from pathlib import Path
import random
import re
import resource
import socket
import statistics
import subprocess
import sys
import sysconfig
import threading
import time
import uuid


SIZES = (500, 1000, 2000)
OUTPUTS = ("numpy", "dict")
PRODUCTS = ("old", "pr", "sdk")
ABIS = ("gil", "ft")
BIN_NAMES = tuple(f"f{i}" for i in range(8))
PICK_BINS = operator.itemgetter(*BIN_NAMES)
POLICY = {"socket_timeout": 5000, "total_timeout": 10000, "max_retries": 0}
POOL_SIZE = 8192
NS = "test"
NANO = 1_000_000_000


def endpoint_config():
    ip = str(ipaddress.IPv4Address(os.environ["DB_HOST"]))
    return {"hosts": [(ip, int(os.getenv("DB_PORT", "3000")))], "cluster_name": os.environ["DB_CLUSTER"]}


def read_exact(sock, n):
    data = bytearray()
    while len(data) < n:
        chunk = sock.recv(n - len(data))
        if not chunk:
            raise EOFError("Aerospike info response ended early")
        data.extend(chunk)
    return bytes(data)


def db_identity(config):
    address = config["hosts"][0]
    query = b"node\ncluster-name\nservice-clear-std\nbuild\nedition\nnamespaces\n"
    with socket.create_connection(address, timeout=5) as sock:
        sock.sendall(b"\x02\x01" + len(query).to_bytes(6, "big") + query)
        header = read_exact(sock, 8)
        size = int.from_bytes(header[2:], "big")
        if header[:2] != b"\x02\x01" or not 1 <= size <= 65536:
            raise ValueError("Invalid Aerospike info response")
        info = dict(line.split("\t", 1) for line in read_exact(sock, size).decode().splitlines())
    assert info["node"].upper() == os.environ["EXPECTED_NODE"].upper()
    assert info["cluster-name"] == config["cluster_name"]
    assert info["build"] == "8.2.0.1" and "Community" in info["edition"]
    assert info["namespaces"].split(";") == [NS]
    assert f"{address[0]}:{address[1]}" in info["service-clear-std"].split(";")
    return info["node"]


def socket_peer_count(config):
    """Verify worker's established IPv4 connections are all to the selected DB."""
    ip, port = config["hosts"][0]
    if sys.platform == "linux":
        own_inodes = set()
        for fd in Path("/proc/self/fd").iterdir():
            try:
                inode = re.fullmatch(r"socket:\[(\d+)\]", os.readlink(fd))
            except FileNotFoundError:
                continue
            if inode:
                own_inodes.add(inode[1])
        peers = []
        for entry in Path("/proc/net/tcp").read_text().splitlines()[1:]:
            fields = entry.split()
            if fields[3] == "01" and fields[9] in own_inodes:
                iphex, porthex = fields[2].split(":")
                peers.append((socket.inet_ntoa(bytes.fromhex(iphex)[::-1]), int(porthex, 16)))
    else:
        output = subprocess.check_output(["lsof", "-nP", "-a", "-p", str(os.getpid()), "-iTCP",
                                          "-sTCP:ESTABLISHED", "-Fn"], text=True)
        peers = []
        for line in output.splitlines():
            if line.startswith("n") and "->" in line:
                host, peer_port = line.split("->", 1)[1].rsplit(":", 1)
                peers.append((host, int(peer_port)))
    assert (ip, port) in peers, peers
    assert all(peer == (ip, port) for peer in peers), peers
    return len(peers)


def expected(i):
    return tuple(i * 8 + j for j in range(8))


def native_digest(path):
    # Do not load a whole debug-bearing extension into the benchmark's RSS.
    with Path(path).open("rb") as extension:
        return hashlib.file_digest(extension, "sha256").hexdigest()


@contextmanager
def open_reader(product, dataset, output, config):
    """Yield (key function, read(keys, phases=None), implementation metadata)."""
    import numpy as np
    dtype = np.dtype([(name, "i8") for name in BIN_NAMES])
    numpy_result = output == "numpy"
    if product == "sdk":
        import aerospike_native._native as native
        from aerospike_sdk import Behavior, DataSet
        from aerospike_sdk.policy.behavior_settings import Settings
        from aerospike_sdk.sync import ClusterDefinition

        settings = Settings(socket_timeout=timedelta(seconds=5), total_timeout=timedelta(seconds=10), max_retries=0)
        behavior = Behavior.DEFAULT.derive_with_changes("FIXED_RATE", all=settings, reads_query=settings)
        dataset_keys = DataSet.of(NS, dataset)
        info = {"version": version("aerospike-sdk"), "native_version": version("aerospike-native"),
                "native_sha256": native_digest(native.__file__)}
        with ClusterDefinition(*config["hosts"][0]).cluster_name(config["cluster_name"]).connect() as cluster:
            client = cluster.create_session(behavior)

            def read(keys, phases=None):
                if phases is not None:
                    started = time.perf_counter_ns()
                with client.query(*keys).execute() as stream:
                    if phases is not None:
                        received = time.perf_counter_ns()
                    rows = stream.collect()
                    if phases is not None:
                        collected = time.perf_counter_ns()
                    if numpy_result:
                        result = np.fromiter((PICK_BINS(row.record.bins) for row in rows),
                                             dtype=dtype, count=len(rows))
                    else:
                        result = [row.record.bins for row in rows]
                if phases is not None:
                    phases.update(submit_and_await_ns=received - started, envelope_ns=collected - received,
                                  convert_ns=time.perf_counter_ns() - collected)
                return result

            yield dataset_keys.id, read, info
    else:
        import aerospike_py as ap
        from aerospike_py import _aerospike as native

        info = {"version": version("aerospike-py"), "native_sha256": native_digest(native.__file__)}
        with ap.client(config).connect() as client:
            def read(keys, phases=None):
                if phases is not None:
                    started = time.perf_counter_ns()
                rows = client.batch_read(keys, policy=POLICY)
                if phases is not None:
                    received = time.perf_counter_ns()
                if numpy_result:
                    result = rows.to_numpy(dtype)
                    if np.any(result.result_codes):
                        raise ValueError("NumPy read returned error rows")
                    value = result.batch_records
                else:
                    value = rows.to_list()
                if phases is not None:
                    phases.update(submit_and_await_ns=received - started, envelope_ns=0,
                                  convert_ns=time.perf_counter_ns() - received)
                return value

            yield lambda i: (NS, dataset, i), read, info


def verify(row, i, numpy_output):
    if (tuple(row) if numpy_output else PICK_BINS(row)) != expected(i):
        raise ValueError("Result keys or bins differ from seeded fixture")


def memory_snapshot():
    if sys.platform == "linux":
        return {k[:-1]: int(v) for line in Path("/proc/self/status").read_text().splitlines()
                if line.startswith(("VmHWM:", "VmRSS:", "RssAnon:", "RssFile:"))
                for k, v, *_ in [line.split()]}
    return {"VmHWM": resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024,
            "VmRSS": int(subprocess.check_output(["ps", "-o", "rss=", "-p", str(os.getpid())], text=True))}


def percentiles(values):
    s = sorted(values)
    if not s:
        return {}
    return {f"p{int(q*100)}_ms": s[math.ceil(len(s)*q)-1] for q in (0.50, 0.95, 0.99)}


def pace(args, read, keys, net_counters):
    """One scheduled arrival per slot, with up to `concurrency` requests active."""
    period_ns = round(NANO * args.size / args.rows_s)
    pending = set()
    samples = []
    missed_slots = 0

    def one(seq, due):
        began = time.perf_counter_ns()
        base, batch = keys[seq % len(keys)]
        try:
            value = read(batch)
            if len(value) != args.size:
                raise ValueError("Incomplete batch")
            checked = seq % args.size
            verify(value[checked], base + checked, args.output == "numpy")
            del value
            err = None
        except Exception as exc:
            err = type(exc).__name__
        end = time.perf_counter_ns()
        return {"seq": seq, "finished_s": (end - due) / NANO, "queue_ms": (began - due) / 1e6,
                "service_ms": (end - began) / 1e6, "scheduled_ms": (end - due) / 1e6, "error": err}

    rss = []
    stop = threading.Event()

    def sample_rss():
        while not stop.wait(0.2):
            rss.append(memory_snapshot())

    before = memory_snapshot()
    monitor = threading.Thread(target=sample_rss, daemon=True)
    monitor.start()
    with ThreadPoolExecutor(max_workers=args.concurrency) as workers:
        start_sync = threading.Barrier(args.concurrency + 1, timeout=10)
        warm_workers = [workers.submit(start_sync.wait) for _ in range(args.concurrency)]
        start_sync.wait()
        for task in warm_workers:
            task.result()
        nic_before = net_counters()
        start = time.perf_counter_ns()
        cpu_start = time.process_time_ns()
        wall_utc = datetime.now(timezone.utc).isoformat()
        for seq in range(args.requests):
            due = start + seq * period_ns
            now = time.perf_counter_ns()
            if due > now:
                time.sleep((due - now) / NANO)
            for task in list(pending):
                if task.done():
                    samples.append(task.result())
                    pending.remove(task)
            if len(pending) >= args.concurrency or time.perf_counter_ns() >= due + period_ns:
                missed_slots += 1
                continue
            pending.add(workers.submit(one, seq, due))
        # The observation window ends after a complete final slot. Late completions
        # remain in the latency and CPU denominators, with the drain time recorded.
        planned_finish = start + args.requests * period_ns
        remaining = planned_finish - time.perf_counter_ns()
        if remaining > 0:
            time.sleep(remaining / NANO)
        for task in pending:
            samples.append(task.result())
        end = time.perf_counter_ns()
        cpu = (time.process_time_ns() - cpu_start) / NANO
        nic_after = net_counters()
    stop.set()
    monitor.join(timeout=2)
    after = memory_snapshot()
    errors = [s["error"] for s in samples if s["error"]]
    good = [s for s in samples if not s["error"]]
    completed = len(good)
    rows = completed * args.size
    elapsed = (end - start) / NANO
    return {
        "started_utc": wall_utc, "finished_utc": datetime.now(timezone.utc).isoformat(),
        "target_rows_s": args.rows_s, "planned_requests": args.requests, "concurrency": args.concurrency,
        "completed_requests": completed, "missed_slots": missed_slots, "errors": errors,
        "rows": rows, "elapsed_s": elapsed, "planned_s": args.requests * period_ns / NANO,
        "drain_ms": max(0., (end - planned_finish) / 1e6), "achieved_rows_s": rows / elapsed,
        "cpu_s": cpu, "cpu_us_row": cpu * 1e6 / rows if rows else None, "mean_cpu_cores": cpu / elapsed,
        "idle_rss_mib": before["VmRSS"] / 1024,
        "peak_rss_mib": after["VmHWM"] / 1024,
        "sampled_peak_rss_mib": max(x["VmRSS"] for x in [before, *rss, after]) / 1024,
        "sampled_peak_anon_mib": max((x.get("RssAnon", 0) for x in [before, *rss, after])) / 1024,
        "rss_samples": len(rss), "rss_after_mib": after["VmRSS"] / 1024,
        "sampled_median_rss_mib": statistics.median(x["VmRSS"] for x in (rss or [before, after])) / 1024,
        "load_vm_nic_rx_bytes": nic_after[0]-nic_before[0] if nic_before else None,
        "load_vm_nic_tx_bytes": nic_after[1]-nic_before[1] if nic_before else None,
        "scheduled": percentiles(q["scheduled_ms"] for q in good),
        "service": percentiles(q["service_ms"] for q in good),
        "scheduler_queue": percentiles(q["queue_ms"] for q in good),
        "samples": sorted(samples, key=lambda s: s["seq"]),
    }


def check_build(product, abi, info):
    assert sys.version_info[:3] == (3, 14, 2)
    assert sys._is_gil_enabled() == (abi == "gil")
    assert bool(sysconfig.get_config_var("Py_GIL_DISABLED")) == (abi == "ft")
    if product in ("old", "sdk"):
        assert info["version"] == {"old": "0.14.4", "sdk": "1.0.0"}[product]
    else:
        expected_hash = os.getenv(f"PR_{abi.upper()}_NATIVE_SHA256")
        if expected_hash:
            assert info["native_sha256"] == expected_hash
    if product == "sdk":
        assert info["native_version"] == "1.0.0"


def run_case(args):
    config = endpoint_config()
    node = db_identity(config)
    with open_reader(args.product, args.dataset, args.output, config) as (make_key, read, info):
        check_build(args.product, args.abi, info)
        source_keys = [make_key(i) for i in range(POOL_SIZE)]
        # Enough disjoint hot windows for the neighboring scheduled requests.
        keys = [(i, source_keys[i:i+args.size]) for i in range(0, POOL_SIZE-args.size+1, args.size)]
        for start, batch in keys:
            # Full validation of every bin outside the measurement window.
            value = read(batch)
            assert len(value) == args.size
            for j, row in enumerate(value):
                verify(row, start+j, args.output == "numpy")
            del value, row
        peers = socket_peer_count(config)
        counter = lambda: None
        if sys.platform == "linux":
            route = json.loads(subprocess.check_output(["ip","-j","-4","route","get",config["hosts"][0][0]],
                                                        text=True))[0]
            counters = Path("/sys/class/net") / route["dev"] / "statistics"
            def counter():
                return tuple(int((counters/file).read_text()) for file in ("rx_bytes","tx_bytes"))
        result = pace(args, read, keys, counter)
        result.update(product=args.product, abi=args.abi, output=args.output, size=args.size,
                      trial=args.trial, node=node, established_db_connections=peers, **info)
        print(json.dumps(result))


def fixture(dataset, remove=False):
    import aerospike_py as ap
    config = endpoint_config()
    db_identity(config)
    assert re.fullmatch(r"eqrate_[0-9a-f]{12}", dataset)
    with ap.client(config).connect() as client:
        for start in range(0, POOL_SIZE, 400):
            keys = [(NS, dataset, j) for j in range(start, min(POOL_SIZE, start+400))]
            if remove:
                assert all(row.result in (0,2) for row in client.batch_remove(keys, policy=POLICY).batch_records)
            else:
                values = [(k, dict(zip(BIN_NAMES, expected(k[2])))) for k in keys]
                assert all(row.result == 0 for row in client.batch_write(values, policy=POLICY).batch_records)


def summarize(path, output):
    groups = defaultdict(list)
    for line in path.read_text().splitlines():
        r = json.loads(line)
        groups[tuple(r[k] for k in ("size", "output", "abi", "product"))].append(r)
    if not groups:
        return
    rows = []
    median_metrics = ("achieved_rows_s", "cpu_us_row", "mean_cpu_cores", "idle_rss_mib",
                      "peak_rss_mib", "sampled_peak_rss_mib", "sampled_peak_anon_mib",
                      "sampled_median_rss_mib", "rss_after_mib", "drain_ms")
    for key, replicates in sorted(groups.items()):
        row = dict(zip(("size", "output", "abi", "product"), key))
        row.update(trials=len(replicates), target_rows_s=replicates[0]["target_rows_s"])
        assert len({r["target_rows_s"] for r in replicates}) == 1
        for k in ("planned_requests", "completed_requests", "missed_slots", "rows"):
            row[k] = sum(r[k] for r in replicates)
        for k in ("load_vm_nic_rx_bytes","load_vm_nic_tx_bytes"):
            values = [r[k] for r in replicates if r.get(k) is not None]
            row[k] = sum(values) if values else None
        latencies = [sample for r in replicates for sample in r["samples"] if not sample["error"]]
        row["errors"] = sum(len(r["errors"]) for r in replicates)
        row["min_achieved_rows_s"] = min(r["achieved_rows_s"] for r in replicates)
        row["equal_rate_valid"] = (row["errors"] == row["missed_slots"] == 0
                                   and row["min_achieved_rows_s"] >= 0.97 * row["target_rows_s"])
        for metric in median_metrics:
            vals = [r[metric] for r in replicates if r[metric] is not None]
            row[metric] = statistics.median(vals) if vals else None
        for stage in ("scheduled", "service", "queue"):
            for p, q in percentiles(s[stage+"_ms"] for s in latencies).items():
                row[f"{stage}_{p}"] = q
        rows.append(row)
    fieldnames = list(dict.fromkeys(k for row in rows for k in row))
    with output.open("w") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def matrix(args):
    args.out_dir.mkdir(parents=True, exist_ok=False)
    case_file = args.out_dir / "cases.jsonl"
    log_file = args.out_dir / "activity.log"
    dataset = args.dataset or "eqrate_" + uuid.uuid4().hex[:12]
    assert re.fullmatch(r"eqrate_[0-9a-f]{12}", dataset)
    groups = [(a, f, n) for n in args.sizes for f in args.outputs for a in args.abis]
    order_seed = random.Random(87072)
    rotations = {g: order_seed.sample(list(PRODUCTS), len(PRODUCTS)) for g in groups}
    exe = {f"{p}-{a}": str(args.env_root / f"{p}-{a}" / "bin/python") for p in PRODUCTS for a in args.abis}
    metadata = {k: str(getattr(args, k)) for k in ("sizes","outputs","abis","rows_s","trials","requests","concurrency")}
    metadata.update(dataset=dataset, node=db_identity(endpoint_config()), status="running")
    manifest = args.out_dir / "run.json"
    manifest.write_text(json.dumps(metadata, indent=2)+"\n")
    own_fixture = args.dataset is None
    started = time.monotonic()
    try:
        if own_fixture:
            fixture(dataset)
        with case_file.open("x",buffering=1) as output, log_file.open("x",buffering=1) as log:
            for trial in range(1,args.trials+1):
                order = []
                group_order = list(groups)
                random.Random(87073+trial).shuffle(group_order)
                for g in group_order:
                    products = rotations[g]
                    offset = (trial-1) % len(products)
                    order.extend((p,*g) for p in products[offset:]+products[:offset])
                for p,a,f,n in order:
                    remaining = args.max_minutes*60 - (time.monotonic()-started)
                    if remaining < max(30, args.requests*n/args.rows_s+20):
                        raise TimeoutError("Fixed-rate matrix deadline approaching")
                    print(datetime.now(timezone.utc).isoformat(), trial, p,a,f,n, file=log)
                    subprocess.run([exe[f"{p}-{a}"],__file__,"case",dataset,p,a,f,str(n),str(trial),
                                    "--rows-s",str(args.rows_s),"--requests",str(args.requests),
                                    "--concurrency",str(args.concurrency)], check=True,
                                   stdout=output, stderr=log,
                                   timeout=min(remaining,max(45,args.requests*n/args.rows_s+40)))
                    if args.interval:
                        time.sleep(args.interval)
        metadata["status"] = "complete"
    except BaseException as exc:
        metadata.update(status="failed", error=f"{type(exc).__name__}: {exc}")
        raise
    finally:
        try:
            if case_file.is_file():
                summarize(case_file, args.out_dir/"summary.csv")
        finally:
            try:
                if own_fixture:
                    fixture(dataset, remove=True)
                    metadata["owned_keys_cleaned"] = True
            finally:
                manifest.write_text(json.dumps(metadata,indent=2)+"\n")


def options(p):
    p.add_argument("--rows-s", type=int, default=90000)
    p.add_argument("--requests", type=int, default=400)
    p.add_argument("--concurrency", type=int, default=4)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="cmd",required=True)
    run = commands.add_parser("matrix")
    run.add_argument("--env-root",type=Path,required=True); run.add_argument("--out-dir",type=Path,required=True)
    run.add_argument("--dataset"); run.add_argument("--max-minutes",type=float,default=32)
    run.add_argument("--trials",type=int,default=3); run.add_argument("--interval",type=float,default=0.4)
    run.add_argument("--sizes",nargs="+",type=int,choices=SIZES,default=SIZES)
    run.add_argument("--outputs",nargs="+",choices=OUTPUTS,default=OUTPUTS)
    run.add_argument("--abis",nargs="+",choices=ABIS,default=ABIS)
    options(run)
    case = commands.add_parser("case")
    case.add_argument("dataset"); case.add_argument("product",choices=PRODUCTS); case.add_argument("abi",choices=ABIS)
    case.add_argument("output",choices=OUTPUTS);case.add_argument("size",type=int,choices=SIZES);case.add_argument("trial",type=int)
    options(case)
    seed = commands.add_parser("seed"); seed.add_argument("dataset")
    clean = commands.add_parser("remove"); clean.add_argument("dataset")
    summary = commands.add_parser("summarize");summary.add_argument("input",type=Path);summary.add_argument("output",type=Path)
    parsed=parser.parse_args()
    if parsed.cmd=="matrix": matrix(parsed)
    elif parsed.cmd=="case": run_case(parsed)
    elif parsed.cmd=="summarize": summarize(parsed.input,parsed.output)
    else: fixture(parsed.dataset,remove=parsed.cmd=="remove")
