"""Validate the raw matrix and render readable compact tables."""

import argparse
import csv
import json
from pathlib import Path
from statistics import median


CLIENTS = ("old", "pr", "sdk")


def summarize(folder, env_manifest=None):
    plan = json.loads((folder / "run.json").read_text())
    rows = list(csv.DictReader((folder / "summary.csv").open()))
    raw = [json.loads(line) for line in (folder / "cases.jsonl").read_text().splitlines()]
    hashes = None
    if env_manifest:
        env = json.loads(env_manifest.read_text())
        assert env["measured_revision"] == "4aabf09f7ca1911a5ba00a3d668ec799c19ed54c"
        hashes = env["venvs"]
    assert plan["status"] == "complete" and plan["owned_keys_cleaned"]
    assert len(raw) == len(rows)*int(plan["trials"])
    for item in raw:
        assert item["node"] == plan["node"] and item["established_db_connections"] > 0
        assert item["completed_requests"] + item["missed_slots"] + len(item["errors"]) == item["planned_requests"]
        assert item["rows"] == item["completed_requests"] * item["size"]
        if hashes:
            assert hashes[f"{item['product']}-{item['abi']}"]["extension_sha256"] == item["native_sha256"]
    print(f"{len(rows)} cells, {len(raw)} runs, {sum(r['rows'] for r in raw):,} rows and "
          f"{sum(r['completed_requests'] for r in raw):,} successful calls")
    print(f"Offer: {int(plan['rows_s']):,} rows/s. "
          f"Measured min/max {min(r['achieved_rows_s'] for r in raw):,.0f}–"
          f"{max(r['achieved_rows_s'] for r in raw):,.0f} rows/s. "
          f"Missed {sum(r['missed_slots'] for r in raw)}, errors {sum(len(r['errors']) for r in raw)}.")
    print(f"Load-host receive {sum(r['load_vm_nic_rx_bytes'] or 0 for r in raw)/1e9:.3f} GB "
          "over the measurement windows.")
    print()
    print("| Python | Keys | Old 0.14.4 | PR #500 | Official SDK |")
    print("|---|---:|---:|---:|---:|")
    cells = {(r["abi"], int(r["size"]), r["product"]): r for r in rows}
    for abi, label in (("gil", "GIL"), ("ft", "FT")):
        for n in (500, 1000, 2000):
            if (abi,n,"pr") not in cells:
                continue
            vals = []
            for p in CLIENTS:
                r = cells[abi, n, p]
                vals.append(f"{float(r['cpu_us_row']):.2f} / {float(r['peak_rss_mib']):.1f} / "
                            f"{float(r['scheduled_p99_ms']):.2f}" + (
                                "*" if r["equal_rate_valid"] != "True" else ""))
            print(f"| {label} | {n:,} | {' | '.join(vals)} |")
    print()
    print("Cells give process CPU µs/row, peak process RSS MiB, and scheduled-to-return p99 ms.")
    print()
    for n in (500, 1000, 2000):
        for abi in ("gil", "ft"):
            if (abi,n,"pr") not in cells:
                continue
            print(n, abi, [(p, sorted(round(x["scheduled"]["p99_ms"],3) for x in raw
                                      if x["abi"]==abi and x["size"]==n and x["product"]==p))
                           for p in CLIENTS])


if __name__=="__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("results", type=Path)
    parser.add_argument("--env-manifest",type=Path)
    args = parser.parse_args()
    summarize(args.results,args.env_manifest)
