"""Plot independently timed phases from sampled Ncloud diagnostic runs."""
import argparse
from pathlib import Path
import csv

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
import numpy as np

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("summary", type=Path)
parser.add_argument("output", type=Path)
args = parser.parse_args()
with args.summary.open() as f:
    rows = [r for r in csv.DictReader(f) if r["mode"] == "ft" and r["api"] == "sync"]
shades = {"old": "#667288", "pr": "#007568", "sdk": "#9150a6"}
names = {"old": "0.14.4", "pr": "aerospike-py 0.15 candidate (4aabf09)", "sdk": "Official SDK 1.0.0"}
fig, axes = plt.subplots(1, 2, figsize=(10.8, 4.05), layout="constrained")
fig.suptitle("Ncloud KR-1  |  FT NumPy batch diagnostics", x=0.02, ha="left", fontsize=19, fontweight="bold")
x = np.arange(3)
for ax, field, title in zip(axes, ("submit_and_return_p50_ms", "convert_p50_ms"),
                            ("Submit until batch returns", "Convert results to NumPy")):
    for position, (product, color) in enumerate(shades.items()):
        ordered = sorted((r for r in rows if r["product"] == product), key=lambda r: int(r["keys"]))
        assert [int(r["keys"]) for r in ordered] == [500, 1000, 2000]
        bars = ax.bar(x + (position - 1) * .24, [float(r[field]) for r in ordered],
                      width=.23, color=color, label=names[product])
        ax.bar_label(bars, fmt="%.2f", padding=3, fontsize=8)
    ax.set_title(title, loc="left")
    ax.set_xticks(x, ["500", "1,000", "2,000"])
    ax.set_xlabel("Keys per batch")
    ax.set_ylabel("Median phase duration (ms)")
    ax.set_ylim(0, ax.get_ylim()[1]*1.18)
    ax.grid(axis="y", alpha=.23)
    ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False)
axes[0].legend(frameon=False, ncol=3, loc="upper left", fontsize=8)
fig.savefig(args.output, dpi=170, facecolor="white", bbox_inches="tight", pad_inches=.28)
