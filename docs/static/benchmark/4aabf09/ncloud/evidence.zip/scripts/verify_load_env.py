"""Assert Python/runtime versions and release hashes and emit benchmark provenance."""
import hashlib
import json
import pathlib
import subprocess
import sys

INSPECT = r"""
import hashlib
from pathlib import Path
from importlib.metadata import version
import json, platform, sys, sysconfig
import numpy, uvloop
kind = sys.argv[1]
if kind == 'sdk':
    import aerospike_native._native as ext
    import aerospike_sdk as sdk
    ver = version('aerospike-sdk')
    assert ver == '1.0.0' and version('aerospike-native') == '1.0.0'
else:
    import aerospike_py._aerospike as ext
    ver = version('aerospike-py')
    assert ver == ('0.14.4' if kind == 'old' else '0.1.0')
assert platform.python_version() == '3.14.2'
assert platform.machine() == 'x86_64' and sys.platform == 'linux'
assert numpy.__version__ == '2.5.5' and uvloop.__version__ == '0.23.0'
free = bool(sysconfig.get_config_var('Py_GIL_DISABLED'))
assert free != sys._is_gil_enabled()
print(json.dumps(dict(abi='ft' if free else 'gil', gil=sys._is_gil_enabled(), python=platform.python_version(),
                      client_version=ver, numpy=numpy.__version__, uvloop=uvloop.__version__,
                      extension_sha256=hashlib.sha256(Path(ext.__file__).read_bytes()).hexdigest())))
"""


def main():
    base = pathlib.Path(sys.argv[1])
    result = {"measured_revision": (base / "source/SOURCE-COMMIT").read_text().strip(), "venvs": {}, "wheels": {}}
    for abi in ("gil", "ft"):
        for kind in ("old", "sdk", "pr", "trace"):
            name = f"{kind}-{abi}"
            py = base / "venvs" / name / "bin/python"
            proc = subprocess.run([str(py), "-c", INSPECT, kind], check=True, text=True, capture_output=True)
            env = json.loads(proc.stdout)
            assert env["abi"] == abi
            result["venvs"][name] = env
        pr = result["venvs"][f"pr-{abi}"]
        trace = result["venvs"][f"trace-{abi}"]
        assert pr["extension_sha256"] == trace["extension_sha256"]
        wheel, = (base / "wheels" / abi).glob("*.whl")
        result["wheels"][abi] = {"name":wheel.name,"sha256":hashlib.sha256(wheel.read_bytes()).hexdigest()}
    collector = base / "venvs/collector/bin/python"
    subprocess.run([str(collector), "-c", "import grpc, opentelemetry.proto"], check=True)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
