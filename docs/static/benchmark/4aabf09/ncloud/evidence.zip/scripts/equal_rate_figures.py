"""Plot the CPU, process RSS and scheduled tail latency of equal-rate cases."""

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
from matplotlib import pyplot as plt
from matplotlib.lines import Line2D

COLORS = {"old": "#656d81", "pr": "#007568", "sdk": "#884c9c"}
NAMES = {"old": "0.14.4", "pr": "aerospike-py 0.15 candidate (4aabf09)", "sdk": "Official SDK 1.0.0"}


def plot(summary, path, form, rss_reference):
    cases = {}
    for row in summary:
        if row["output"] != form:
            continue
        key = (row["abi"], row["product"])
        cases.setdefault(key, []).append(row)
    if len(cases) not in (3,6) or not all(len(rows)==3 for rows in cases.values()):
        raise ValueError("Need complete three-client/three-key-size comparison per build")
    rates = {int(row["target_rows_s"]) for values in cases.values() for row in values}
    if len(rates) != 1:
        raise ValueError("Mixed offer rates")
    if rss_reference is not None:
        amounts = {(r["abi"], r["product"], r["size"], r["output"], r["target_rows_s"]): r["peak_rss_mib"]
                   for r in rss_reference}
        for values in cases.values():
            for row in values:
                row["peak_rss_mib"] = amounts[tuple(row[k] for k in ("abi","product","size","output","target_rows_s"))]
    abis = [a for a in ("gil", "ft") if (a, "pr") in cases]
    fig, axes = plt.subplots(len(abis), 3, squeeze=False, figsize=(12.5, 3.2 * len(abis) + 0.8),
                             sharex=True, layout="constrained")
    fig.get_layout_engine().set(rect=(0.012, 0.08, 0.976, 0.83))
    rate = rates.pop()
    fig.suptitle(f"Ncloud KR-1 private network  |  Batch read → {form} at {rate:,} rows/s",
                 x=.022, y=.982, ha="left", fontsize=18, fontweight="bold")
    for i, abi in enumerate(abis):
        for j,(field, label) in enumerate((("cpu_us_row","Process CPU (µs per row)"),
                                            ("peak_rss_mib","Peak RSS (MiB), short rerun" if rss_reference is not None else "Process peak RSS (MiB)"),
                                            ("scheduled_p99_ms","Scheduled-to-completion p99 (ms)"))):
            ax = axes[i][j]
            ax.set_title(label,loc="left",fontsize=12)
            ax.set_xticks([500, 1000, 2000], ("500", "1,000", "2,000"))
            ax.set_ylabel("CPython" if abi=="gil" else "Free-threaded")
            ax.set_axisbelow(True)
            ax.grid(axis="y",alpha=.23)
            ax.spines[["right","top"]].set_visible(False)
            if i==len(abis)-1:
                ax.set_xlabel("Keys per call")
            for p in ("old", "pr", "sdk"):
                rows=sorted(cases[(abi,p)],key=lambda d:int(d["size"]))
                x=[int(row["size"]) for row in rows]
                y=[float(row[field]) for row in rows]
                ax.plot(x,y,color=COLORS[p],lw=1.6)
                for size,value,row in zip(x,y,rows):
                    good=row["equal_rate_valid"]=="True"
                    ax.scatter(size,value,color=COLORS[p],marker="o" if good else "x",s=30,zorder=4)
    legend = [Line2D([0],[0],c=COLORS[p],marker="o",label=NAMES[p]) for p in ("old","pr","sdk")]
    if not all(row["equal_rate_valid"]=="True" for v in cases.values() for row in v):
        legend.append(Line2D([0],[0],c="#343c45",marker="x",ls="",label="Rate or errors failed validation"))
    fig.legend(handles=legend,loc="lower center",frameon=False,ncol=len(legend))
    fig.savefig(path,dpi=170,facecolor="#fff",bbox_inches="tight",pad_inches=.24)


if __name__=="__main__":
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("summary",type=Path)
    parser.add_argument("output",type=Path)
    parser.add_argument("--form",choices=["numpy","dict"],default="numpy")
    parser.add_argument("--abi",choices=["gil","ft"])
    parser.add_argument("--rss-reference",type=Path)
    args=parser.parse_args()
    with args.summary.open() as f:
        rows = [row for row in csv.DictReader(f) if not args.abi or row["abi"] == args.abi]
    rss = None
    if args.rss_reference:
        with args.rss_reference.open() as f:
            rss = list(csv.DictReader(f))
    plot(rows, args.output,args.form,rss)
