#!/usr/bin/env bash
# Run on the owned load generator after the uninstrumented matrix.
set -euo pipefail
umask 077
venvs=$1
out=$2
rate=${3:-180000}
code=$(cd "$(dirname "$0")" && pwd -P)
mkdir "$out"
out=$(cd "$out" && pwd -P)
pr="$venvs/pr-ft/bin/python"
trace_ft="$venvs/trace-ft/bin/python"
trace_gil="$venvs/trace-gil/bin/python"
collector="$venvs/collector/bin/python"
py_site=$("$trace_ft" -c 'import sysconfig; print(sysconfig.get_path("purelib"))')
mkdir "$out/pure"
for package in opentelemetry importlib_metadata zipp typing_extensions.py; do
    if [[ -e "$py_site/$package" ]]; then ln -s "$py_site/$package" "$out/pure/$package"; fi
done
dataset=$("$pr" -c 'from uuid import uuid4; print("eqrate_"+uuid4().hex[:12])')
receiver=""
seeded=""
cleanup() {
    if [[ -n "$receiver" ]]; then kill "$receiver" 2>/dev/null || true; fi
    if [[ -n "$seeded" ]]; then "$pr" "$code/fixed_rate.py" remove "$dataset"; fi
}
trap cleanup EXIT
"$collector" "$code/trace_batch.py" collect --ready "$out/collector.port" --out "$out/native.jsonl" > "$out/collector.log" 2>&1 &
receiver=$!
for _ in {1..20}; do [[ -s "$out/collector.port" ]] && break; sleep 0.4; done
[[ -s "$out/collector.port" ]]
port=$(cat "$out/collector.port")
seeded=1
"$pr" "$code/fixed_rate.py" seed "$dataset"
for n in 500 1000 2000; do
    for product in old pr sdk; do
        python="$venvs/$product-ft/bin/python"
        if [[ "$product" == pr ]]; then python="$trace_ft"; fi
        PYTHONPATH="$out/pure" "$python" "$code/trace_batch.py" run --product "$product" --api sync \
            --keys "$n" --calls 120 --rows-s "$rate" --dataset "$dataset" --otlp-port "$port" --out "$out/ft-sync-$product-$n.json"
    done
    for abi in ft gil; do
        python="$trace_ft"
        if [[ "$abi" == gil ]]; then python="$trace_gil"; fi
        "$python" "$code/trace_batch.py" run --product pr --api async --keys "$n" --calls 120 \
            --rows-s "$rate" --dataset "$dataset" --otlp-port "$port" --out "$out/$abi-async-pr-$n.json"
    done
done
for trial in 1 2; do
    order=(tuple digest)
    if [[ "$trial" == 2 ]]; then order=(digest tuple); fi
    for mode in "${order[@]}"; do
        extra=()
        if [[ "$mode" == digest ]]; then extra=(--prepared-digest); fi
        "$trace_ft" "$code/trace_batch.py" run --product pr --api async --keys 2000 --calls 120 \
            --rows-s "$rate" --dataset "$dataset" --otlp-port "$port" \
            --out "$out/ft-async-pr-$mode-2000-$trial.json" "${extra[@]}"
    done
done
for n in 500 2000; do
    for product in old pr sdk; do
        python="$venvs/$product-gil/bin/python"
        if [[ "$product" == pr ]]; then python="$trace_gil"; fi
        PYTHONPATH="$out/pure" "$python" "$code/trace_batch.py" run --product "$product" --api sync \
            --keys "$n" --calls 60 --rows-s 60000 --dataset "$dataset" --otlp-port "$port" --out "$out/gil-sync-$product-$n.json"
    done
done
echo "Completed matched detailed spans and per-stage histograms."
