# Ncloud equal-rate batch-read evidence

Collected on 2026-11-22 on two Ubuntu 24.04 x86-64 guests in Ncloud KR-1, each with four Intel Xeon Gold 5220 vCPUs. The load guest and the Aerospike CE 8.2.0.1 guest used the same private subnet. The database had a single node and an isolated, replication-factor-one, pure-memory test namespace.

The three clients were aerospike-py 0.14.4, the aerospike-py 0.15 candidate built from revision `4aabf09f7ca1911a5ba00a3d668ec799c19ed54c` (PR #500), and the official Aerospike Python SDK and native wheels at 1.0.0. CPython 3.14.2 was tested with and without the GIL. [The environment manifest](observed/load-environments.json) records the GIL state after imports, measured wheel hashes and installed package metadata. The pinned candidate wheel has in-development package metadata of `0.1.0`, recorded as installed in that manifest.

## Which data produced the published charts

- [Free-threaded comparison](observed/numpy-ft-90000-comparison.csv) combines CPU, achieved rate, and scheduled p99 from the 90,000 rows/s [main arm](observed/numpy-main/summary.csv) with process peak RSS from the [clean RSS arm](observed/numpy-ft-clean-rss/summary.csv). The main arm has 1,200 measured calls per client and batch size. The clean rerun has 180 calls per cell at the same rate. The original preflight loaded each native extension into a single Python bytes object to hash it, which contaminated the original process peak RSS. The rerun streamed the same hash. The main CPU and latency measurement windows started after preflight.
- [Standard CPython comparison](observed/numpy-gil-60000/summary.csv) uses 60,000 rows/s for all three clients and batch sizes. Each cell uses 1,050 measured calls and streaming hashing. The standard CPython 90,000 rows/s rows in the main arm and the [180,000 rows/s pilot](observed/pilot-numpy-180/summary.csv) show overload behavior. Compare clients at the same offer and ABI.
- [Trace summary](observed/trace-ncloud/trace-summary.csv) contains separate one-at-a-time diagnostics. The trace collector matched 206 Rust `BATCH_READ` child spans to sampled Python batch spans. Sampling was 12.5%, and PR async calls also enabled stage timing. The two tuple/digest pairs alternate order and use the same keys. Reported submit-to-return, conversion, and total p50 values summarize their own measurements. Interpreting their sum as total p50 would change the statistic. The native `io` measure includes batch setup, I/O and response handling. [Small-request timings](observed/small-request-summary.json) and [server/load host counters](observed/host-numpy-main.json) give separate network and host context.
- Each measured arm directory contains its run manifest, per-request timestamps and durations in `cases.jsonl`, and the aggregation in `summary.csv`. In the trace directory, each case JSON contains the phase timings, and `native.jsonl` holds the exported span IDs and time bounds used in the join. Dataset identifiers and the database node identifier have been pseudonymized consistently within each arm.

## Workload and measurement

All clients read the same pool of 8,192 synthetic rows with eight signed 64-bit integer bins. Aerospike-py materializes a structured NumPy array via `batch_read().to_numpy(dtype)`. The official SDK runs `session.query(*keys).execute()` and builds an equivalent structured array with `numpy.fromiter` from the returned bins. All product runs use zero retries, a 5 s socket timeout, and a 10 s total timeout. Warmup verifies all returned rows. Timed calls verify length and a rotating row.

The fixed-deadline scheduler allows four outstanding sync calls, counts missed arrivals, then drains scheduled work. Each cell aggregates fresh worker processes with rotating client order. Equal-rate validation requires every trial to finish with zero errors, zero missed slots, and at least 97% of the targeted row rate. CPU measures total process CPU time, summed across the process's threads, per returned row. RSS is the median of worker peak RSS measurements in MiB and includes imports and prewarming. Scheduled p99 pools per-request measurements from the intended arrival through materialization and validation. The host NIC totals include other VM traffic. Baseline load measurements run with tracing off.

## Reproduce on a dedicated Linux test database

Create a private test instance and use an empty or disposable `test` namespace. Set `DB_HOST` to its advertised private IPv4 address, `DB_PORT` to its data port (3000 by default), `DB_CLUSTER` to its cluster name, and `EXPECTED_NODE` to its node ID from the Aerospike info protocol. The harness verifies the endpoint and the worker's TCP peers. It creates and removes its own set for each matrix.

Use an absolute `VENVS` directory, Linux CPython 3.14.2 and 3.14.2t, and install these isolated environments. All six baseline environments use NumPy 2.5.5 and uvloop 0.23.0.

| Environment | Package |
| --- | --- |
| `old-gil`, `old-ft` | `aerospike-py==0.14.4` binary wheels |
| `pr-gil`, `pr-ft` | Candidate wheels built from the pinned revision |
| `sdk-gil`, `sdk-ft` | `aerospike-sdk==1.0.0` and `aerospike-native==1.0.0` binary wheels |

The measured wheel build used uv 0.9.26, Rust 1.100.0 and maturin 1.13.3. Use an absolute `WHEELS` output directory. Set `abi` to `gil` or `ft` and use the corresponding interpreter when building each wheel from the candidate source checkout.

```sh
uvx --from maturin==1.13.3 maturin build --release --locked --compatibility linux \
  --interpreter "$VENVS/pr-$abi/bin/python" -o "$WHEELS/$abi"
```

Run these from the unpacked archive. The current harness uses streaming file hashing for both ABIs. Original measurement provenance stays with the archived data.

```sh
driver="$VENVS/pr-gil/bin/python"
"$driver" scripts/fixed_rate.py matrix --env-root "$VENVS" --out-dir repeat-ft \
  --outputs numpy --abis ft --rows-s 90000 --requests 400 --trials 3
"$driver" scripts/fixed_rate.py matrix --env-root "$VENVS" --out-dir repeat-ft-rss \
  --outputs numpy --abis ft --rows-s 90000 --requests 60 --trials 3
"$driver" scripts/fixed_rate.py matrix --env-root "$VENVS" --out-dir repeat-gil \
  --outputs numpy --abis gil --rows-s 60000 --requests 350 --trials 3
```

For tracing, install the same candidate wheel for each ABI, NumPy and uvloop, plus `opentelemetry-api==1.45.2` and `opentelemetry-sdk==1.45.2` in `trace-gil` and `trace-ft`. Set up `collector` with regular CPython 3.14.2, `grpcio==1.85.3`, and `opentelemetry-proto==1.45.2`. The helper runs a local loopback OTLP collector and creates its own temporary dataset. To regenerate the environment manifest, arrange the `venvs/` directory and `wheels/` output under a common directory, include the measured commit in `source/SOURCE-COMMIT` beneath it, and run `python scripts/verify_load_env.py <common-directory>`.

```sh
bash scripts/run_trace_probe.sh "$VENVS" repeat-trace 90000
"$driver" scripts/summarize_trace_batch.py repeat-trace
```

## Regenerate the evidence tables and figures offline

The Python summaries use the standard library. The figure scripts use NumPy and Matplotlib. Regenerating the trace CSV needs a directory without an existing `trace-summary.csv`, so copy the observed trace files to a separate location before running the trace summary.

```sh
python scripts/fixed_rate.py summarize observed/numpy-main/cases.jsonl main-rebuilt.csv
python scripts/fixed_rate.py summarize observed/numpy-ft-clean-rss/cases.jsonl ft-rss-rebuilt.csv
python scripts/fixed_rate.py summarize observed/numpy-gil-60000/cases.jsonl gil-rebuilt.csv
python scripts/equal_rate_figures.py observed/numpy-main/summary.csv ft-90000.png \
  --abi ft --rss-reference observed/numpy-ft-clean-rss/summary.csv
python scripts/equal_rate_figures.py observed/numpy-gil-60000/summary.csv gil-60000.png --abi gil
python scripts/plot_trace_phases.py observed/trace-ncloud/trace-summary.csv trace-phases.png
```
